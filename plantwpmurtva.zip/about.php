<p><br />
  - RTVA / Canal Sur Radio</p>
<p>Edificio Canal Sur. Avda. Jos&eacute; G&aacute;lvez, 1.</p>
<p>CP: 41092. Isla de la Cartuja (Sevilla)</p>
<p>Tel&eacute;fono: 955 054 600 / RCJA: 354 600</p>
<p>Correo electr&oacute;nico: comunicacion@rtva.es</p>
<p>&nbsp;</p>
<p>- Canal Sur Televisi&oacute;n</p>
<p>Ctra San Juan de Aznalfarache-Tomares, km 1'3</p>
<p>CP: 41920. San Juan de Aznalfarache (Sevilla)</p>
<p>Tel&eacute;fono: 955 054 600 / RCJA: 354 600</p>
