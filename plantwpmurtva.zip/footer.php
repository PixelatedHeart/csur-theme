<?php
echo "	<div class=\"footer-shadow\"><div class=\"none\"></div></div>\n";
echo "	<div class=\"footer-bar\"><div class=\"none\"></div></div>\n";
echo "	<div class=\"footer\"><div class=\"footer-content\">\n";
echo "		<div class=\"footer-columns clear\">\n";
echo "			<div class=\"footer-ad\">\n";
include(TEMPLATEPATH."/ads/before-footer-columns.php");
echo "			</div>\n";
echo "			<div class=\"footer-column-left\"><div class=\"footer-column-content\">\n";
include(TEMPLATEPATH."/ads/before-footer-column-left.php");
IF (!function_exists("dynamic_sidebar") || !dynamic_sidebar(obt_translate("Footer - Left"))){
	obt_widget_latestentries();
};
include(TEMPLATEPATH."/ads/after-footer-column-left.php");
echo "			</div></div>\n";
echo "			<div class=\"footer-column-center\"><div class=\"footer-column-content\">\n";
include(TEMPLATEPATH."/ads/before-footer-column-center.php");
IF (!function_exists("dynamic_sidebar") || !dynamic_sidebar(obt_translate("Footer - Center"))){
	obt_widget_latestcomments();
};
include(TEMPLATEPATH."/ads/after-footer-column-center.php");
echo "			</div></div>\n";
echo "			<div class=\"footer-column-right\"><div class=\"footer-column-content\">\n";
include(TEMPLATEPATH."/ads/before-footer-column-right.php");
IF (!function_exists("dynamic_sidebar") || !dynamic_sidebar(obt_translate("Footer - Right"))){
	obt_widget_mostcommented();
};
include(TEMPLATEPATH."/ads/after-footer-column-right.php");
echo "			</div></div>\n";
echo "		</div>\n";
echo "		<div class=\"footer-credits\" style=\"clear:both\">\n";
include(TEMPLATEPATH."/ads/after-footer-columns.php");
include(TEMPLATEPATH."/ads/before-footer-credits.php");
wp_footer();
echo "<ul>\n";
echo "\t<li><a href=\"".get_option("home")."/\" title=\"".obt_translate("Back to homepage")."\">".get_bloginfo("name")."</a> = ";
IF (strpos($wp_version,"mu") !== false) echo "<a href=\"http://mu.wordpress.org/\">WordPress ".str_replace("wordpress-mu-","MU ",get_bloginfo("version"));
ELSE echo "<a href=\"http://www.wordpress.org/\">WordPress ".get_bloginfo("version");
echo "</a> + <a href=\"http://es.1blogtheme.com/\">1 Blog Theme</a> <a href=\"http://1blogr.com/\">(".obt_translate("by %1","1Blogr").")</a> + <a href=\"http://validator.w3.org/check?uri=".urlencode("http://".$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"])."\">XHTML</a> + <a href=\"http://jigsaw.w3.org/css-validator/validator?uri=".urlencode("http://".$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"])."\">CSS</a>.</li>\n";
echo "</ul>\n";
include(TEMPLATEPATH."/ads/after-footer-credits.php");
echo "		</div>\n";
echo "	</div></div>\n";
include(TEMPLATEPATH."/ads/before-body-close-tag.php");
echo "</body>\n";
echo "</html>\n";
echo "<!-- ".obt_translate("Loaded in %1 seconds with %2 database queries",timer_stop(0,2),$wpdb->num_queries)." -->\n";
?>