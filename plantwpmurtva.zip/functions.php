<?php
$obt_memory_limit = trim(ini_get("memory_limit"));
$obt_memory_unit = strtolower(substr($obt_memory_limit,-1));
$obt_memory_limit = (int) $obt_memory_limit;
SWITCH ($obt_memory_unit) {
	CASE "g": $obt_memory_limit *= 1024;
	CASE "m": $obt_memory_limit *= 1024;
	CASE "k": $obt_memory_limit *= 1024;
};
IF ($obt_memory_limit >= 0 && $obt_memory_limit < 24*1024*1024) @ini_set("memory_limit","24M");

require_once(dirname(__FILE__)."/theme-translation.php");
require_once(dirname(__FILE__)."/theme-functions.php");
require_once(dirname(__FILE__)."/theme-options.php");
require_once(dirname(__FILE__)."/theme-admin.php");
require_once(dirname(__FILE__)."/theme-feeds.php");
require_once(dirname(__FILE__)."/theme-feed-content.php");
require_once(dirname(__FILE__)."/theme-widgets.php");
require_once(dirname(__FILE__)."/theme-comment-notification.php");
require_once(dirname(__FILE__)."/theme-antispam.php");
require_once(dirname(__FILE__)."/theme-tags.php");
?>