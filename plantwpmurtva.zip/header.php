<?php
global $obt_comments_paginated, $paged, $obt_comments_this_page;
IF (is_home()){
	$obt_title = wp_specialchars(get_bloginfo("name"),true);
	IF (strlen(get_bloginfo("description"))) $obt_title .= ": ".wp_specialchars(get_bloginfo("description"),true);
	$obt_description = wp_specialchars(obt_first_titles(5),true);
}ELSEIF (is_404()){
	$obt_title = $obt_description = obt_translate("No post was found");
}ELSEIF (is_single() || is_page()){
	$obt_title = apply_filters("the_title",$post->post_title);
	IF (!strlen($obt_title)) $obt_title = obt_translate("Untitled");
	IF (strlen($post->post_password)) $obt_title = obt_translate("%1 (protected)",$obt_title);
	$obt_title = wp_specialchars($obt_title,true);
	$obt_description = $obt_title;
	IF ($obt_comments_paginated){
		IF (is_single()) $obt_description = obt_translate("You are currently viewing the comments for the post %1 on the blog %2",$obt_title,wp_specialchars(get_bloginfo("name"),true));
		IF (is_page()) $obt_description = obt_translate("You are currently viewing the comments for the post %1 on the blog %2",$obt_title,wp_specialchars(get_bloginfo("name"),true));
		$obt_title = obt_translate("Comments").": ".$obt_title;
	}ELSE{
		IF (!strlen($post->post_excerpt)){
			$obt_post_excerpt = get_the_content();
			$obt_post_excerpt = apply_filters("get_the_excerpt",$obt_post_excerpt);
			$obt_post_excerpt = apply_filters("the_excerpt",$obt_post_excerpt);
			$obt_post_excerpt = obt_excerpt($obt_post_excerpt);
		}ELSE{
			$obt_post_excerpt = $post->post_excerpt;
			$obt_post_excerpt = apply_filters("get_the_excerpt",$post->post_excerpt);
			$obt_post_excerpt = apply_filters("the_excerpt",$obt_post_excerpt);
			$obt_post_excerpt = str_replace(array("<br />","</p>","</ul>","</ol>","</blockquote>","\n")," ",$obt_post_excerpt);
			$obt_post_excerpt = strip_tags($obt_post_excerpt);
			WHILE (strpos($obt_post_excerpt,"  ") !== false) $obt_post_excerpt = str_replace("  "," ",$obt_post_excerpt);
			$text = trim($obt_post_excerpt);
		};
		IF (strlen($obt_post_excerpt)) $obt_description .= ": ".$obt_post_excerpt;
	};
}ELSEIF (is_category()){
	$obt_title = $obt_description = wp_specialchars(ucfirst(single_cat_title("",false)),true);
	$obt_category_description = category_description();
	IF (trim($obt_category_description) == "</p>") $obt_category_description = "";
	IF (strlen($obt_category_description)) $obt_title .= ": ".obt_excerpt($obt_category_description,10);
	$obt_description .= ": ".wp_specialchars(obt_first_titles(5),true);
	unset($obt_category);
}ELSE{
	IF (obt_is_tag()) $obt_title = $obt_description = ucfirst(obt_current_tag());
	ELSEIF (is_search()){
		$obt_title = $obt_description = wp_specialchars(ucfirst($s),true);
		IF ($obt_tags = wp_specialchars(ucfirst(obt_tag_keywords(3,$s)),true)) $obt_title .= ": {$obt_tags}";
	}ELSEIF (is_year()) $obt_title = $obt_description = get_the_time("Y");
	ELSEIF (is_month()) $obt_title = $obt_description = obt_translate("%1 %2",obt_translate_months(get_the_time("F")),get_the_time("Y"));
	ELSEIF (is_day()) $obt_title = $obt_description = obt_translate("%2 %1 %3",get_the_time("j"),obt_translate_months(get_the_time("F")),get_the_time("Y"));
	ELSEIF (is_author()) $obt_title = $obt_description = wp_specialchars(get_the_author_nickname(),true);
	$obt_description .= ": ".wp_specialchars(obt_first_titles(5),true);
};
IF ($paged > 1){
	$obt_title .= ": ".obt_translate("Page %1",$paged);
	$obt_description = obt_translate("Page %1",$paged).": {$obt_description}";
};
IF ($obt_comments_this_page > 1){
	$obt_title .= ": ".obt_translate("Page %1",$obt_comments_this_page);
	$obt_description = obt_translate("Page %1",$obt_comments_this_page).": {$obt_description}";
};
IF (!is_404()) IF (is_category()){
	IF (!strlen($obt_category_description)) IF ($obt_tags = wp_specialchars(ucfirst(obt_tag_keywords(3,single_cat_title("",false))),true)) $obt_title .= ": {$obt_tags}";
	$obt_keywords = wp_specialchars(ucfirst(single_cat_title("",false)),true);
	IF ($obt_tags = wp_specialchars(obt_tag_keywords(9,single_cat_title("",false)),true)) $obt_keywords .= ", {$obt_tags}";
}ELSEIF (obt_is_tag()){
	IF ($obt_tags = wp_specialchars(ucfirst(obt_tag_keywords(3,obt_current_tag())),true)) $obt_title .= ": {$obt_tags}";
	$obt_keywords = wp_specialchars(ucfirst(obt_current_tag()),true);
	IF ($obt_tags = wp_specialchars(obt_tag_keywords(9,obt_current_tag()),true)) $obt_keywords .= ", {$obt_tags}";
}ELSE{
	IF (is_date() || is_author()) $obt_title .= ": ".wp_specialchars(ucfirst(obt_tag_keywords(3)));
	$obt_keywords = wp_specialchars(ucfirst(obt_tag_keywords()),true);
};
IF (!is_home()){
	IF (obt_get_themeoption("site-title") != "beginning") $obt_title .= ": ".wp_specialchars(get_bloginfo("name"),true);
	ELSE $obt_title = wp_specialchars(get_bloginfo("name"),true).": {$obt_title}";
};
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">\n";
echo "<head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=".get_bloginfo("charset")."\" />\n";
echo "<title>{$obt_title}</title>\n";
echo "<meta name=\"title\" content=\"{$obt_title}.\" />\n";
echo "<meta name=\"description\" content=\"{$obt_description}\" />\n";
echo "<meta name=\"keywords\" content=\"{$obt_keywords}\" />\n";
IF (strpos($wp_version,"mu") !== false) echo "<meta name=\"generator\" content=\"WordPress ".str_replace("wordpress-mu-","MU ",get_bloginfo("version"))."\" />\n";
ELSE echo "<meta name=\"generator\" content=\"WordPress ".get_bloginfo("version")."\" />\n";
echo "<link rel=\"shortcut icon\" href=\"".get_bloginfo("template_directory")."/favicon.ico\" />\n";
echo "<link rel=\"alternate nofollow\" href=\"".obt_fix_link(obt_get_feed_url("entries"))."\" type=\"application/rss+xml\" title=\"".get_bloginfo("name")."\" />\n";
IF (get_option("blog_public") === "0") echo "<meta name=\"robots\" content=\"noindex, nofollow\" />\n";
ELSEIF (is_404() || (!is_home() && !is_single() && !is_page() && (obt_get_themeoption("meta-noindex") == "archives" || obt_get_themeoption("meta-noindex") == "paginated-archives" && $paged > 1))) echo "<meta name=\"robots\" content=\"noindex, follow\" />\n";

IF (is_single() || is_page()){
	IF ($post->ping_status == "open"){
		echo "<link rel=\"trackback\" href=\"".obt_fix_link(trackback_url(false))."\" title=\"".obt_translate("Trackback this post")."\" />\n";
		echo "<link rel=\"pingback\" href=\"".get_bloginfo("pingback_url")."\" title=\"".obt_translate("Pingback this post")."\" />\n";
	};
};
echo "<link rel=\"stylesheet\" href=\"".get_bloginfo("template_directory")."/style.php?align=".urlencode(obt_get_themeoption("align"))."&amp;width=".urlencode(obt_get_themeoption("width"))."&amp;sidebaralign=".urlencode(obt_get_themeoption("sidebaralign"))."&amp;sidebarwidth=".urlencode(obt_get_themeoption("sidebarwidth"))."&amp;leftsidebarwidth=".urlencode(obt_get_themeoption("leftsidebarwidth"))."&amp;linkhue=".urlencode(obt_get_themeoption("linkhue"))."&amp;linksaturation=".urlencode(obt_get_themeoption("linksaturation"))."&amp;headerhue=".urlencode(obt_get_themeoption("headerhue"))."&amp;headersaturation=".urlencode(obt_get_themeoption("headersaturation"))."&amp;headerlight=".urlencode(obt_get_themeoption("headerlight"))."&amp;background=".urlencode(obt_get_themeoption("background"))."&amp;menu=".urlencode(obt_get_themeoption("menu"))."&amp;imagenomargins=".urlencode(obt_get_themeoption("imagenomargins"))."&amp;gzip=".(get_option("gzipcompression")*1)."\" type=\"text/css\" media=\"all\" />\n";
echo "<script type=\"text/javascript\" src=\"".get_bloginfo("template_directory")."/javascript.php?gzip=".(get_option("gzipcompression")*1)."\"></script>\n";
IF (obt_use_buffer()){
	ob_start();
	wp_head();
	wp_meta();
	$obt_meta = ob_get_contents();
	ob_end_clean();
	$obt_meta = obt_clean_meta($obt_meta);
	echo $obt_meta;
	unset($obt_meta);
}ELSE{
	wp_head();
	wp_meta();
};
include(TEMPLATEPATH."/ads/before-head-close-tag.php");
echo "</head>\n";
echo "<body>\n";
include(TEMPLATEPATH."/ads/after-body-open-tag.php");
echo "	<div class=\"header-top\"><div class=\"none\"></div></div>\n";
echo "	<div class=\"header-background\"><div class=\"header\"><div class=\"header-content clear\">\n";
echo "		<div class=\"header-title\">\n";
include(TEMPLATEPATH."/ads/before-header-title.php");
IF (preg_match("'^http:\/\/(.*)\.(.*)$'",obt_get_themeoption("image"))) echo "<h1><a href=\"".get_option("home")."/\" title=\"".wp_specialchars(get_bloginfo("name"),true).": ".wp_specialchars(get_bloginfo("description"),true)."\"><img src=\"".obt_get_themeoption("image")."\" width=\"".obt_get_themeoption("imagewidth")."\" height=\"".obt_get_themeoption("imageheight")."\" alt=\"".wp_specialchars(get_bloginfo("name"),true).": ".wp_specialchars(get_bloginfo("name"),true)."\" /></a></h1>\n";
ELSE echo "<h1><a href=\"".get_option("home")."/\" title=\"".wp_specialchars(get_bloginfo("description"),true)."\">".wp_specialchars(get_bloginfo("name"),true)."</a></h1>\n";
include(TEMPLATEPATH."/ads/after-header-title.php");
echo "		</div>\n";
IF (obt_get_themeoption("menu") != "regular"){
	echo "		<div class=\"header-menu\">\n";
	obt_widget_pages_list();
	echo "		</div>\n";
};
echo "		<div class=\"clear\"></div>\n";
include(TEMPLATEPATH."/ads/after-header-content.php");
echo "		</div></div></div>\n";
echo "		<div class=\"header-bar\"><div class=\"none\"></div></div>\n";
echo "		<div class=\"header-shadow\"><div class=\"none\"></div></div>\n";
echo "		<div class=\"body\"><div class=\"body-content clear\">\n";
include(TEMPLATEPATH."/ads/after-header.php");
echo "		<div class=\"main\"><div class=\"main-content\">\n";
?>
