<?php
require_once(TEMPLATEPATH."/functions.php");
$obt_comments_order = obt_get_themeoption("comments-order");
$obt_comments_per_page = obt_get_themeoption("comments-pagination")*1;
$obt_comments_post_full = obt_get_themeoption("comments-post-full");
$obt_comments_this_page = $_GET[obt_translate("comments")];
$obt_comments_paginated = ($obt_comments_per_page > 0 && $obt_comments_this_page > 0);

global $user_ID;
extract(wp_get_current_commenter(),EXTR_SKIP);

$obt_check_trackbacks = false;
IF (!is_array($obt_social_domains)) $obt_social_domains = array();
FOREACH ($obt_social_domains AS $social_domain) IF (obt_get_themeoption("share-{$social_domain}")){
	$obt_check_trackbacks = true;
	BREAK;
};
IF (have_posts() && !is_404()){
	WHILE (have_posts()){
		the_post();
		IF ($wp_query->current_post == 0) get_header();
		IF ($wp_query->current_post == 0) include(TEMPLATEPATH."/ads/before-all-posts.php");
		include(TEMPLATEPATH."/ads/before-post.php");
		echo "				<div class=\"post\"><div class=\"post-content clear\">\n";
		echo "<!-- google_ad_section_start -->\n";
		include(TEMPLATEPATH."/post.php");
		echo "				</div></div>\n";
		include(TEMPLATEPATH."/ads/after-post.php");
		include(TEMPLATEPATH."/ads/before-post-info.php");
		echo "				<div class=\"post-info\"><div class=\"post-info-content clear\">\n";
		IF (!$obt_comments_paginated && !is_page()) include(TEMPLATEPATH."/post-related.php");
		echo "<!-- google_ad_section_end -->\n";
		include(TEMPLATEPATH."/post-share.php");
		echo "				</div></div>\n";
		include(TEMPLATEPATH."/ads/after-post-info.php");
		IF ($wp_query->current_post == $wp_query->post_count - 1 || is_single() || is_page()){
			include(TEMPLATEPATH."/ads/after-all-posts.php");
			IF (!is_single() && !is_page()) include(TEMPLATEPATH."/pagination.php");
			ELSE include(TEMPLATEPATH."/comments.php");
			get_sidebar();
			get_footer();
			break;
		};
	};
}ELSE{
	IF (!is_search()) $wp_query->is_404 = true;
	get_header();
	include(TEMPLATEPATH."/ads/before-all-posts.php");
	include(TEMPLATEPATH."/ads/before-post.php");
	echo "				<div class=\"post\"><div class=\"post-content clear\">\n";
	echo "<!-- google_ad_section_start -->\n";
	include(TEMPLATEPATH."/ads/before-post-title.php");
	echo "<h2>".obt_translate("Not found")."</h2>\n";
	include(TEMPLATEPATH."/ads/after-post-title.php");
	include(TEMPLATEPATH."/ads/before-post-content.php");
	echo "<div class=\"post-text clear\">\n";
	echo "<p>".obt_translate("No post was found for your query. Back to the %1 homepage, try the search form or browse the different categories and sections","<a href=\"".get_option("home")."/\">".get_bloginfo("name")."</a>").".</p>\n";
	echo "</div>\n";
	include(TEMPLATEPATH."/ads/after-post-content.php");
	echo "<!-- google_ad_section_end -->\n";
	echo "				</div></div>\n";
	include(TEMPLATEPATH."/ads/after-post.php");
	include(TEMPLATEPATH."/ads/after-all-posts.php");
	get_sidebar();
	get_footer();
};
?>
