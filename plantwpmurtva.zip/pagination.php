<?php
$obt_nofollow = (in_array(obt_get_themeoption("meta-noindex"),array("archives","paginated-archives")) && !is_home())? " rel=\"nofollow\"" : "";
IF (!$max_page){
	IF (isset($max_num_pages)) $obt_total_pages = $max_page = $max_num_pages;
	ELSE {
		IF ($wp_query->max_num_pages) $obt_total_pages = $max_page = $wp_query->max_num_pages;
		ELSE {
			preg_match("'FROM\s(.*)\sGROUP BY'siU",$request,$obt_matches);
			$obt_from = $obt_matches[1];
			$obt_total_posts = $wpdb->get_var("SELECT COUNT(DISTINCT ID) FROM $obt_from");
			$obt_total_pages = $max_page = $max_num_pages = ceil($obt_total_posts / $posts_per_page);
		}
	}
}
$obt_this_page = ($paged)? $paged : 1;
IF ($obt_this_page > 1 || $obt_this_page < $obt_total_pages){
	echo "<p class=\"pagination\">\n";
	IF ($obt_this_page > 1) echo "<a href=\"".obt_fix_link(get_pagenum_link($obt_this_page-1))."\"{$obt_nofollow}>&larr; ".obt_translate("Previous")."</a>\n";
	ELSE echo "<s>&larr; ".obt_translate("Previous")."</s>\n";
	IF ($obt_this_page + 2 > $obt_total_pages){
		$obt_page_start = max($obt_total_pages-4,1);
		$obt_page_end = $obt_total_pages;
	}ELSEIF ($obt_this_page - 2 < 1){
		$obt_page_start = 1;
		$obt_page_end = min(5,$obt_total_pages);
	}ELSE {
		$obt_page_start = max($obt_this_page - 2,1);
		$obt_page_end = min($obt_this_page+2,$obt_total_pages);
	};
	IF ($obt_page_start > 1) echo "<a href=\"".obt_fix_link(get_pagenum_link(1))."\"{$obt_nofollow}>01</a> ... \n";
	FOR ($x = $obt_page_start; $x <= $obt_page_end; $x++){
		IF ($x != $obt_this_page) echo "<a href=\"".obt_fix_link(get_pagenum_link($x))."\"{$obt_nofollow}>".obt_fill_zeroes($x)."</a>\n";
		ELSE echo "<s>".obt_fill_zeroes($x)."</s>\n";
	};
	IF ($obt_page_end < $obt_total_pages) echo "... <a href=\"".obt_fix_link(get_pagenum_link($obt_total_pages))."\"{$obt_nofollow}>".obt_fill_zeroes($obt_total_pages)."</a>\n";
	IF ($obt_this_page < $obt_total_pages) echo "<a href=\"".obt_fix_link(get_pagenum_link($obt_this_page+1))."\"{$obt_nofollow}>".obt_translate("Next")." &rarr;</a>\n";
	ELSE echo "<s>".obt_translate("Next")." &rarr;</s>\n";
	echo "</p>\n";
};
?>
