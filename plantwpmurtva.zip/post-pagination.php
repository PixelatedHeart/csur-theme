<?php
IF ($multipage){
	echo "<p class=\"pagination\">\n";
	echo "<strong>".obt_translate("Pages on this post")."</strong>";
	IF ($page > 1) echo "<a href=\"".obt_post_page_url($obt_post_url,$page-1)."\">&larr; ".obt_translate("Previous")."</a>\n";
	ELSE echo "<s>&larr; ".obt_translate("Previous")."</s>\n";
	FOR ($x = 1; $x < $numpages+1; $x++){
		IF ($x != $page) echo "<a href=\"".obt_post_page_url($obt_post_url,$x)."\">".obt_fill_zeroes($x)."</a>\n";
		ELSE echo "<s>".obt_fill_zeroes($x)."</s>\n";
	};
	IF ($page < $numpages) echo "<a href=\"".obt_post_page_url($obt_post_url,$page+1)."\">".obt_translate("Next")." &rarr;</a>\n";
	ELSE echo "<s>".obt_translate("Next")." &rarr;</s>\n";
	echo "</p>\n";
};
?>
