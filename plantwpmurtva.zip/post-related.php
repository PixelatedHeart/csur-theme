<?php
include(TEMPLATEPATH."/ads/before-post-related.php");
echo "<h3>".obt_translate("Related posts")."</h3>\n";
IF (!is_category() && !obt_is_tag() && (is_single() || is_page() || (!is_single() && !is_page() && !is_home() && obt_get_themeoption("posts-archives") == "full") || (is_home() && obt_get_themeoption("posts") == "full"))){
	flush();
	$obt_now = current_time("mysql",1);
	$obt_related_posts = obt_related_posts($obt_now);
	IF (count($obt_related_posts)){
		echo "<ul>\n";
		FOREACH ($obt_related_posts as $obt_related_post){
			$obt_related_post_title = apply_filters("the_title",$obt_related_post->post_title);
			IF (!strlen($obt_related_post_title)) $obt_related_post_title = obt_translate("Untitled");
			$obt_related_post_title = wp_specialchars($obt_related_post_title,true);
			echo "\t<li><a href=\"".get_permalink($obt_related_post->ID)."\" title=\"".obt_translate("Permanent link to this post")."\">{$obt_related_post_title}</a>: ".obt_translate("%1 ago",obt_time_ago($obt_related_post->post_date_gmt))."</li>\n";
		};
		echo "</ul>\n";
		unset($obt_related_posts);
	};
};
echo "<ul>\n";
echo "\t<li>".obt_translate("Categories").": ";
flush();
IF ($obt_categories = get_the_category($post->ID)){
	usort($obt_categories,"obt_sort_categories");
	$obt_comma = false;
	FOREACH ($obt_categories as $obt_category){
		IF ($obt_comma) echo ", ";
		$obt_comma = true;
		$obt_category_name = wp_specialchars($obt_category->cat_name,true);
		$obt_category_link = get_category_link($obt_category->cat_ID);
		$obt_category_feed = get_category_rss_link(false,$obt_category->cat_ID,$obt_category->category_nicename);
		$obt_category_link = obt_fix_link($obt_category_link);
		$obt_category_feed = obt_fix_feed_link($obt_category_feed,$obt_category_link);
		echo "<a href=\"{$obt_category_link}\" title=\"".obt_translate("View all posts under the category %1","&laquo;{$obt_category_name}&raquo;")."\" rel=\"tag\">{$obt_category_name}</a>";
		IF (obt_get_themeoption("feed-categories")) echo " <a href=\"{$obt_category_feed}\" title=\"".obt_translate("Subscribe to posts under the category %1","&laquo;{$obt_category_name}&raquo;")."\" rel=\"nofollow\">(<small>RSS</small>)</a>";
	};
	unset($obt_categories);
}ELSE echo obt_translate("No categories");
echo "</li>\n";
IF (function_exists("get_the_tags")){
	IF ($obt_tags = get_the_tags($post->ID)){
		echo "\t<li>".obt_translate("Tags").": ";
		usort($obt_tags,"obt_sort_tags");
		$obt_comma = false;
		FOREACH ($obt_tags as $obt_tag){
			IF ($obt_comma) echo ", ";
			$obt_comma = true;
			$obt_tag_name = wp_specialchars($obt_tag->name,true);
			$obt_tag_link = get_tag_link($obt_tag->term_id);
			$obt_tag_feed = obt_tag_feed($obt_tag_link);
			$obt_tag_link = obt_fix_link($obt_tag_link);
			$obt_tag_feed = obt_fix_feed_link($obt_tag_feed,$obt_tag_link);
			echo "<a href=\"{$obt_tag_link}\" title=\"".obt_translate("View all posts tagged %1","&laquo;{$obt_tag_name}&raquo;")."\" rel=\"tag\">{$obt_tag_name}</a>";
			IF (obt_get_themeoption("feed-tags")) echo " <a href=\"{$obt_tag_feed}\" title=\"".obt_translate("Subscribe to posts tagged %1","&laquo;{$obt_tag_name}&raquo;")."\" rel=\"nofollow\">(<small>RSS</small>)</a>";
		};
		unset($obt_tags);
		echo "</li>\n";
	};
}ELSEIF (function_exists("UTW_ShowTagsForCurrentPost")){
	global $utw, $baseurl, $home, $siteurl, $prettyurls;
	flush();
	$obt_tags = $utw->GetTagsForPost($post->ID);
	IF (count($obt_tags)){
		echo "\t<li>".obt_translate("Tags").": ";
		$obt_comma = false;
		FOREACH ($obt_tags as $obt_tag){
			IF ($obt_comma) echo ", ";
			$obt_comma = true;
			$obt_tag_name = str_replace("_"," ",$obt_tag->tag);
			$obt_tag_name = str_replace("-"," ",$obt_tag_name);
			$obt_tag_name = stripslashes($obt_tag_name);
			$obt_tag_name = wp_specialchars($obt_tag_name);
			$obt_tag_name_url = urlencode(stripslashes(strtolower($obt_tag->tag)));
			IF ($prettyurls == "yes"){
				$obt_tag_link = "{$home}{$baseurl}{$obt_tag_name_url}/";
				$obt_tag_feed = "{$obt_tag_link}feed/";
			}ELSE{
				$obt_tag_link = "$home/index.php?tag={$obt_tag_name_url}";
				$obt_tag_feed = "{$obt_tag_link}&amp;feed=rss";
			};
			echo "<a href=\"{$obt_tag_link}\" title=\"".obt_translate("View all posts tagged %1","&laquo;{$obt_tag_name}&raquo;")."\" rel=\"tag\">{$obt_tag_name}</a>";
			IF (obt_get_themeoption("feed-tags")) echo " <a href=\"{$obt_tag_feed}\" title=\"".obt_translate("Subscribe to posts tagged %1","&laquo;{$obt_tag_name}&raquo;")."\" rel=\"nofollow\">(<small>RSS</small>)</a>";
		};
		unset($obt_tags);
		echo "</li>\n";
	};
}ELSEIF (function_exists("STP_GetPostTags")){
	global $STagging;
	flush();
	$obt_tags = $STagging->getPostTags($post->ID);
	IF (count($obt_tags)){
		echo "\t<li>".obt_translate("Tags").": ";
		$obt_comma = false;
		FOREACH ($obt_tags as $obt_tag){
			IF ($obt_comma) echo ", ";
			$obt_comma = true;
			$obt_tag_link = $STagging->getTagPermalink($obt_tag);
			$obt_tag_feed = obt_tag_feed($obt_tag_link);
			$obt_tag_link = obt_fix_link($obt_tag_link);
			$obt_tag_feed = obt_fix_feed_link($obt_tag_feed,$obt_tag_link);
			$obt_tag_name = wp_specialchars($obt_tag);
			echo "<a href=\"{$obt_tag_link}\" title=\"".obt_translate("View all posts tagged %1","&laquo;{$obt_tag_name}&raquo;")."\" rel=\"tag\">{$obt_tag_name}</a>";
			IF (obt_get_themeoption("feed-tags")) echo " <a href=\"{$obt_tag_feed}\" title=\"".obt_translate("Subscribe to posts tagged %1","&laquo;{$obt_tag_name}&raquo;")."\" rel=\"nofollow\">(<small>RSS</small>)</a>";
		};
		unset($obt_tags);
		echo "</li>\n";
	};
};
echo "</ul>\n";
include(TEMPLATEPATH."/ads/after-post-related.php");
?>