<?php
include(TEMPLATEPATH."/ads/before-post-share-buttons.php");
echo "<h3>".obt_translate("Share this post")."</h3>\n";
echo "					<div class=\"share\">\n";
echo "						<div class=\"share-left\">\n";
$obt_total_comments = $obt_total_trackbacks = 0;
$obt_comments = $obt_trackbacks = array();
$obt_comment_where = "comment_post_ID = '{$post->ID}' AND ";
IF ($obt_can_moderate_comments) $obt_comment_where .= "comment_approved = '1'";
ELSEIF ($user_ID) $obt_comment_where .= "(comment_approved = '1' OR (user_id = '{$user_ID}' AND comment_approved = '0'))";
ELSEIF (strlen($comment_author)) $obt_comment_where .= "(comment_approved = '1' OR (comment_author_email = '".$wpdb->escape($comment_author_email)."' AND comment_approved = '0'))";
ELSE $obt_comment_where .= "comment_approved = '1'";
flush();
IF (is_single() || is_page()){
	$obt_comments_query_order = ($obt_comments_order == "newer")? " DESC" : "";
	IF ($obt_comments_per_page > 0){
		$obt_total_comments = $wpdb->get_var("SELECT COUNT(comment_post_ID) AS total_comments FROM {$wpdb->comments} WHERE {$obt_comment_where} AND comment_type IN ('','comment')");
		$obt_comments_total_pages = ceil($obt_total_comments / $obt_comments_per_page);
		IF ($obt_comments_this_page <= $obt_comments_total_pages){
			$obt_comments_uncomplete_first_page = ($obt_comments_order == "newer" && !$obt_comments_post_full);
			$obt_comments_first_comments = $obt_total_comments % $obt_comments_per_page;
			IF ($obt_comments_this_page < 1) $obt_comments_this_page = ($obt_comments_order == "newer")? $obt_comments_total_pages : 1;
				$obt_comments_query_length = $obt_comments_per_page;
				$obt_comments_start = ($obt_comments_order == "newer")? ($obt_comments_total_pages - $obt_comments_this_page) * $obt_comments_query_length: ($obt_comments_this_page - 1) * $obt_comments_query_length;
				IF ($obt_comments_uncomplete_first_page && $obt_comments_first_comments > 0){
					IF ($obt_comments_this_page == $obt_comments_total_pages){
						$obt_comments_start = 0;
						$obt_comments_query_length = $obt_comments_first_comments;
					}ELSE $obt_comments_start = $obt_total_comments - ($obt_comments_this_page * $obt_comments_query_length);
				};
			$obt_comments = $wpdb->get_results("SELECT * FROM {$wpdb->comments} WHERE {$obt_comment_where} AND comment_type IN ('','comment') ORDER BY comment_date_gmt{$obt_comments_query_order} LIMIT {$obt_comments_start},{$obt_comments_query_length}");
		};
		$obt_trackbacks = $wpdb->get_results("SELECT * FROM {$wpdb->comments} WHERE {$obt_comment_where} AND comment_type NOT IN ('','comment') ORDER BY comment_date_gmt");
		$obt_total_trackbacks = count($obt_trackbacks);
	}ELSE{
		$obt_comments = $wpdb->get_results("SELECT * FROM {$wpdb->comments} WHERE {$obt_comment_where} AND comment_type IN ('','comment') ORDER BY comment_date_gmt{$obt_comments_query_order}");
		$obt_total_comments = count($obt_comments);
		$obt_trackbacks = $wpdb->get_results("SELECT * FROM {$wpdb->comments} WHERE {$obt_comment_where} AND comment_type NOT IN ('','comment') ORDER BY comment_date_gmt");
		$obt_total_trackbacks = count($obt_trackbacks);
	};
}ELSE{
	IF ($obt_check_trackbacks){
		$obt_total_comments = $wpdb->get_var("SELECT COUNT(comment_post_ID) AS total_comments FROM {$wpdb->comments} WHERE {$obt_comment_where} AND comment_type IN ('','comment')");
		$obt_trackbacks = $wpdb->get_results("SELECT * FROM {$wpdb->comments} WHERE {$obt_comment_where} AND comment_type NOT IN ('','comment')");
		$obt_total_trackbacks = count($obt_trackbacks);
	}ELSE{
		$obt_comments = $wpdb->get_results("SELECT comment_type IN ('','comment') AS comment_type, COUNT(*) as comment_count FROM {$wpdb->comments} WHERE {$obt_comment_where} GROUP BY comment_type");
		IF (is_array($obt_comments)) FOREACH ($obt_comments as $obt_comment){
			IF ($obt_comment->comment_type == 1) $obt_total_comments = $obt_comment->comment_count;
			IF ($obt_comment->comment_type == 0) $obt_total_trackbacks = $obt_comment->comment_count;
		};
	};
};

IF (!is_array($obt_comments)) $obt_comments = array();
IF (!is_array($obt_trackbacks)) $obt_trackbacks = array();
IF ($obt_check_trackbacks){
	$obt_social_urls = array();
	FOREACH ($obt_trackbacks as $obt_trackback){
		$obt_domain = parse_url($obt_trackback->comment_author_url);
		$obt_domain = $obt_domain["host"];
		IF ($obt_social_domains[$obt_domain]) IF (!$obt_social_urls[$obt_social_domains[$obt_domain]]) $obt_social_urls[$obt_social_domains[$obt_domain]] = $obt_trackback->comment_author_url;
	};
};
$wpdb->comment_count = $obt_total_comments;
IF ($obt_pending_comments && $obt_comments) $obt_comments = array_merge($obt_pending_comments,$obt_comments);
ELSEIF ($obt_pending_comments) $obt_comments = $obt_pending_comments;
unset($obt_pending_comments);
echo "<div id=\"sharePlacer{$post->ID}\"></div>\n";
echo "<ul id=\"shareMenu{$post->ID}\" class=\"social-buttons\">\n";
IF (obt_get_themeoption("share-barrapunto")) echo "\t<li><a href=\"http://barrapunto.com/submit.pl?story=".urlencode(obt_translate("I've just read on the blog %1 the post %2","<a href=\"".get_option("home")."/\">".get_bloginfo("name")."</a>","<a href=\"{$obt_post_url}\">{$post->post_title}</a>")."...")."&amp;subj=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Submit this post to %1","Barrapunto")."\" target=\"_blank\"><img src=\"".get_bloginfo("template_directory")."/images/social-barrapunto.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Submit this post to %1","Barrapunto")."\" />Barrapunto</a></li>\n";
IF (obt_get_themeoption("share-blinklist")) echo "\t<li><a href=\"http://www.blinklist.com/index.php?Action=Blink/addblink.php&amp;Description=&amp;Url=".urlencode($obt_post_url)."&amp;Title=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Add this post to %1","BlinkList")."\" target=\"_blank\"><img src=\"".get_bloginfo("template_directory")."/images/social-blinklist.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Add this post to %1","BlinkList")."\" />BlinkList</a></li>\n";
IF (obt_get_themeoption("share-blogmemes")) echo "\t<li><a href=\"http://www.blogmemes.com/post.php?url=".urlencode($obt_post_url)."&amp;title=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Submit this post to %1","BlogMemes")."\" target=\"_blank\"><img src=\"".get_bloginfo("template_directory")."/images/social-blogmemes.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Submit this post to %1","BlogMemes")."\" />BlogMemes</a></li>\n";
IF (obt_get_themeoption("share-corank")) echo "\t<li><a href=\"http://www.corank.com/submit?url=".urlencode($obt_post_url)."&amp;title=".urlencode($post->post_title)."&amp;source=w\" rel=\"nofollow\" title=\"".obt_translate("Submit this post to %1","CoRank")."\" target=\"_blank\"><img src=\"".get_bloginfo("template_directory")."/images/social-corank.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Submit this post to %1","CoRank")."\" />CoRank</a></li>\n";
IF (obt_get_themeoption("share-corank-es")) echo "\t<li><a href=\"http://es.corank.com/submit?url=".urlencode($obt_post_url)."&amp;title=".urlencode($post->post_title)."&amp;source=w\" rel=\"nofollow\" title=\"".obt_translate("Submit this post to %1","CoRank Espa&ntilde;ol")."\" target=\"_blank\"><img src=\"".get_bloginfo("template_directory")."/images/social-corank.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Submit this post to %1","CoRank Espa&ntilde;ol")."\" />CoRank Espa&ntilde;ol</a></li>\n";
IF (obt_get_themeoption("share-delicious")) echo "\t<li><a href=\"http://del.icio.us/post?url=".urlencode($obt_post_url)."&amp;title=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Add this post to %1","Delicious")."\" target=\"_blank\"><img src=\"".get_bloginfo("template_directory")."/images/social-delicious.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Add this post to %1","Delicious")."\" />Delicious</a></li>\n";
IF (obt_get_themeoption("share-digg")) echo "\t<li><a href=\"http://digg.com/submit?phase=2&amp;url=".urlencode($obt_post_url)."&amp;title=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Submit this post to %1","Digg")."\" target=\"_blank\"><img src=\"".get_bloginfo("template_directory")."/images/social-digg.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Submit this post to %1","Digg")."\" />Digg</a></li>\n";
IF (obt_get_themeoption("share-enchilame")) echo ($obt_social_urls["enchilame"])? "\t<li><a href=\"{$obt_social_urls["enchilame"]}\" rel=\"nofollow\" title=\"".obt_translate("Vote for this post on %1","Ench&iacute;lame")."\" /><img src=\"".get_bloginfo("template_directory")."/images/social-enchilame.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Vote for this post on %1","Ench&iacute;lame")."\" />Ench&iacute;lame</a>: ".obt_translate("Vote this post!")."</li>\n" : "\t<li><a href=\"http://www.enchilame.com/submit.php?url=".urlencode($obt_post_url)."\" rel=\"nofollow\" title=\"".obt_translate("Submit this post to %1","Ench&iacute;lame")."\" target=\"_blank\"><img src=\"".get_bloginfo("template_directory")."/images/social-enchilame.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Submit this post to %1","Ench&iacute;lame")."\" />Ench&iacute;lame</a></li>\n";
IF (obt_get_themeoption("share-fark")) echo "\t<li><a href=\"http://cgi.fark.com/cgi/fark/edit.pl?new_url=".urlencode($obt_post_url)."&amp;new_comment=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Submit this post to %1","Fark")."\" target=\"_blank\"><img src=\"".get_bloginfo("template_directory")."/images/social-fark.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Submit this post to %1","Fark")."\" />Fark</a></li>\n";
IF (obt_get_themeoption("share-fresqui-act")) echo ($obt_social_urls["fresqui-act"])? "\t<li><a href=\"{$obt_social_urls["fresqui-act"]}\" rel=\"nofollow\" title=\"".obt_translate("Vote for this post on %1","Fresqui Actualidad")."\" /><img src=\"".get_bloginfo("template_directory")."/images/social-fresqui.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Vote for this post on %1","Fresqui Actualidad")."\" />Fresqui Actualidad</a>: ".obt_translate("Vote this post!")."</li>\n" : "\t<li><a href=\"http://act.fresqui.com/post?url=".urlencode($obt_post_url)."&amp;title=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Submit this post to %1","Fresqui Actualidad")."\" target=\"_blank\"><img src=\"".get_bloginfo("template_directory")."/images/social-fresqui.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Submit this post to %1","Fresqui Actualidad")."\" />Fresqui Actualidad</a></li>\n";
IF (obt_get_themeoption("share-fresqui-ocio")) echo ($obt_social_urls["fresqui-ocio"])? "\t<li><a href=\"{$obt_social_urls["fresqui-ocio"]}\" rel=\"nofollow\" title=\"".obt_translate("Vote for this post on %1","Fresqui Ocio")."\" /><img src=\"".get_bloginfo("template_directory")."/images/social-fresqui.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Vote for this post on %1","Fresqui Ocio")."\" />Fresqui Ocio</a>: ".obt_translate("Vote this post!")."</li>\n" : "\t<li><a href=\"http://ocio.fresqui.com/post?url=".urlencode($obt_post_url)."&amp;title=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Submit this post to %1","Fresqui Ocio")."\" target=\"_blank\"><img src=\"".get_bloginfo("template_directory")."/images/social-fresqui.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Submit this post to %1","Fresqui Ocio")."\" />Fresqui Ocio</a></li>\n";
IF (obt_get_themeoption("share-fresqui-tec")) echo ($obt_social_urls["fresqui-tec"])? "\t<li><a href=\"{$obt_social_urls["fresqui-tec"]}\" rel=\"nofollow\" title=\"".obt_translate("Vote for this post on %1","Fresqui Tecnolog&iacute;a")."\" /><img src=\"".get_bloginfo("template_directory")."/images/social-fresqui.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Vote for this post on %1","Fresqui Tecnolog&iacute;a")."\" />Fresqui Tecnolog&iacute;a</a>: ".obt_translate("Vote this post!")."</li>\n" : "\t<li><a href=\"http://tec.fresqui.com/post?url=".urlencode($obt_post_url)."&amp;title=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Submit this post to %1","Fresqui Tecnolog&iacute;a")."\" target=\"_blank\"><img src=\"".get_bloginfo("template_directory")."/images/social-fresqui.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Submit this post to %1","Fresqui Tecnolog&iacute;a")."\" />Fresqui Tecnolog&iacute;a</a></li>\n";
IF (obt_get_themeoption("share-furl")) echo "\t<li><a href=\"http://furl.net/storeIt.jsp?u=".urlencode($obt_post_url)."&amp;t=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Add this post to %1","Furl")."\" target=\"_blank\"><img src=\"".get_bloginfo("template_directory")."/images/social-furl.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Add this post to %1","Furl")."\" />Furl</a></li>\n";
IF (obt_get_themeoption("share-google")) echo "\t<li><a href=\"http://www.google.com/bookmarks/mark?op=edit&amp;bkmk=".urlencode($obt_post_url)."&amp;title=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Add this post to %1","Google Bookmarks")."\" target=\"_blank\"><img src=\"".get_bloginfo("template_directory")."/images/social-google.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Add this post to %1","Google Bookmarks")."\" />Google Bookmarks</a></li>\n";
IF (obt_get_themeoption("share-live")) echo "\t<li><a href=\"https://favorites.live.com/quickadd.aspx?marklet=1&amp;mkt=es-es&amp;url=".urlencode($obt_post_url)."&amp;title=".urlencode($post->post_title)."&amp;top=1\" rel=\"nofollow\" title=\"".obt_translate("Add this post to %1","Live Favorites")."\" target=\"_blank\"><img src=\"".get_bloginfo("template_directory")."/images/social-live.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Add this post to %1","Live Favorites")."\" />Live Favorites</a></li>\n";
IF (obt_get_themeoption("share-magnolia")) echo "\t<li><a href=\"http://ma.gnolia.com/bookmarklet/add?url=".urlencode($obt_post_url)."&amp;title=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Add this post to %1","Magnolia")."\" target=\"_blank\"><img src=\"".get_bloginfo("template_directory")."/images/social-magnolia.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Add this post to %1","Magnolia")."\" />Magnolia</a></li>\n";
IF (obt_get_themeoption("share-meneame")) echo ($obt_social_urls["meneame"])? "\t<li><a href=\"{$obt_social_urls["meneame"]}\" rel=\"nofollow\" title=\"".obt_translate("Vote for this post on %1","Men&eacute;ame")."\" /><img src=\"".get_bloginfo("template_directory")."/images/social-meneame.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Vote for this post on %1","Men&eacute;ame")."\" />Men&eacute;ame</a>: ".obt_translate("Vote this post!")."</li>\n" : "\t<li><a href=\"http://meneame.net/submit.php?url=".urlencode($obt_post_url)."\" rel=\"nofollow\" title=\"".obt_translate("Submit this post to %1","Men&eacute;ame")."\" target=\"_blank\"><img src=\"".get_bloginfo("template_directory")."/images/social-meneame.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Submit this post to %1","Men&eacute;ame")."\" />Men&eacute;ame</a></li>\n";
IF (obt_get_themeoption("share-neodiario")) echo "\t<li><a href=\"http://www.neodiario.net/submit.php?url=".urlencode($obt_post_url)."&amp;title=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Submit this post to %1","Neodiario")."\" target=\"_blank\"><img src=\"".get_bloginfo("template_directory")."/images/social-neodiario.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Submit this post to %1","Neodiario")."\" />Neodiario</a></li>\n";
IF (obt_get_themeoption("share-netscape")) echo "\t<li><a href=\"http://www.netscape.com/submit/?U=".urlencode($obt_post_url)."&amp;T=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Submit this post to %1","Netscape")."\" target=\"_blank\"><img src=\"".get_bloginfo("template_directory")."/images/social-netscape.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Submit this post to %1","Netscape")."\" />Netscape</a></li>\n";
IF (obt_get_themeoption("share-newsvine")) echo "\t<li><a href=\"http://www.newsvine.com/_wine/save?u=".urlencode($obt_post_url)."&amp;h=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Submit this post to %1","Newsvine")."\" target=\"_blank\"><img src=\"".get_bloginfo("template_directory")."/images/social-newsvine.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Submit this post to %1","Newsvine")."\" />Newsvine</a></li>\n";
IF (obt_get_themeoption("share-reddit")) echo "\t<li><a href=\"http://reddit.com/submit?url=".urlencode($obt_post_url)."&amp;title=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Submit this post to %1","Reddit")."\" target=\"_blank\"><img src=\"".get_bloginfo("template_directory")."/images/social-reddit.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Submit this post to %1","Reddit")."\" />Reddit</a></li>\n";
IF (obt_get_themeoption("share-rojo")) echo "\t<li><a href=\"http://www.rojo.com/submit/?url=".urlencode($obt_post_url)."&amp;title=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Submit this post to %1","Rojo")."\" target=\"_blank\"><img src=\"".get_bloginfo("template_directory")."/images/social-rojo.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Submit this post to %1","Rojo")."\" />Rojo</a></li>\n";
IF (obt_get_themeoption("share-slashdot")) echo "\t<li><a href=\"http://slashdot.org/bookmark.pl?url=".urlencode($obt_post_url)."&amp;title=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Submit this post to %1","Slashdot")."\" target=\"_blank\"><img src=\"".get_bloginfo("template_directory")."/images/social-slashdot.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Submit this post to %1","Slashdot")."\" />Slashdot</a></li>\n";
IF (obt_get_themeoption("share-spurl")) echo "\t<li><a href=\"http://www.spurl.net/spurl.php?url=".urlencode($obt_post_url)."&amp;title=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Add this post to %1","Spurl")."\" target=\"_blank\"><img src=\"".get_bloginfo("template_directory")."/images/social-spurl.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Add this post to %1","Spurl")."\" />Spurl</a></li>\n";
IF (obt_get_themeoption("share-stumbleupon")) echo "\t<li><a href=\"http://www.stumbleupon.com/submit?url=".urlencode($obt_post_url)."&amp;title=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Submit this post to %1","Stumbleupon")."\" target=\"_blank\"><img src=\"".get_bloginfo("template_directory")."/images/social-stumbleupon.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Submit this post to %1","Stumbleupon")."\" />Stumbleupon</a></li>\n";
IF (obt_get_themeoption("share-technorati")) echo "\t<li><a href=\"http://www.technorati.com/faves?add=".urlencode($obt_post_url)."\" rel=\"nofollow\" title=\"".obt_translate("Add this post to %1","Technorati Favorites")."\" target=\"_blank\"><img src=\"".get_bloginfo("template_directory")."/images/social-technorati.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Add this post to %1","Technorati Favorites")."\" />Technorati Favorites</a></li>\n";
IF (obt_get_themeoption("share-yahoo")) echo "\t<li><a href=\"http://myweb2.search.yahoo.com/myresults/bookmarklet?u=".urlencode($obt_post_url)."&amp;t=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Add this post to %1","Yahoo MyWeb")."\" target=\"_blank\"><img src=\"".get_bloginfo("template_directory")."/images/social-yahoo.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Add this post to %1","Yahoo MyWeb")."\" />Yahoo MyWeb</a></li>\n";
echo "</ul>\n";
echo "<div id=\"shareForm{$post->ID}\">\n";
echo "<p>".obt_translate("In order to send this post to a friend, enter his/her email and also your data").":</p>\n";
include(TEMPLATEPATH."/send-form.php");
echo "</div>\n";
echo "<script type=\"text/javascript\">\n";
echo "<!--\n";
IF ($_SERVER["REQUEST_METHOD"] == "GET" && !strlen($comment_author)) echo "fillForm(\"".COOKIEHASH."\",\"send-email-{$post->ID}\",\"send-name-{$post->ID}\");\n";
echo "initMenu({$post->ID},\"share\",\"".obt_translate("Social bookmarkers")."\",\"".get_bloginfo("template_directory")."/images/social-share.gif\",\"".obt_translate("Display social bookmarkers for this post")."\",\"".obt_translate("Email this post")."\",\"".get_bloginfo("template_directory")."/images/social-email.gif\",\"".obt_translate("Send this post by email")."\");\n";
echo "//-->\n";
echo "</script>\n";
echo "						</div>\n";
echo "						<div class=\"share-right\">\n";
echo "<ul class=\"social-buttons\">\n";
echo "\t<li>";
IF ($obt_total_comments == 1) echo "<a href=\"".((is_single() || is_page())? "" : $obt_post_url)."#".obt_translate("comments")."\" title=\"".obt_translate("Read the comment on this post")."\"><img src=\"".get_bloginfo("template_directory")."/images/social-comments.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Read the comment on this post")."\" />".obt_translate("1 comment")."</a>";
ELSEIF ($obt_total_comments > 1) echo "<a href=\"".((is_single() || is_page())? "" : $obt_post_url)."#".obt_translate("comments")."\" title=\"".obt_translate("Read the comments on this post")."\"><img src=\"".get_bloginfo("template_directory")."/images/social-comments.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Read the comments on this post")."\" />".obt_translate("%1 comments",$obt_total_comments)."</a>";
ELSE{
	IF ($post->comment_status == "open") echo "<a href=\"".((is_single() || is_page())? "" : $obt_post_url)."#".obt_translate("respond")."\" title=\"".obt_translate("Write a comment on this post")."\"><img src=\"".get_bloginfo("template_directory")."/images/social-comments.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("No comments")."\" />".obt_translate("Write a comment")."</a>";
	ELSE echo "<img src=\"".get_bloginfo("template_directory")."/images/social-comments.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Comments disabled")."\" />".obt_translate("Comments disabled");
};
echo "</li>\n";
echo "\t<li>";
IF ($obt_total_trackbacks == 1) echo "<a href=\"{$obt_post_url}#".obt_translate("trackbacks")."\" title=\"".obt_translate("Read the trackback to this post")."\"><img src=\"".get_bloginfo("template_directory")."/images/social-trackbacks.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Read the trackback to this post")."\" />".obt_translate("1 trackback")."</a>";
ELSEIF ($obt_total_trackbacks > 1) echo "<a href=\"{$obt_post_url}#".obt_translate("trackbacks")."\" title=\"".obt_translate("Read the trackbacks to this post")."\"><img src=\"".get_bloginfo("template_directory")."/images/social-trackbacks.gif\" width=\"14\" height=\"14\" alt=\"".obt_translate("Read the trackbacks to this post")."\" />".obt_translate("%1 trackbacks",$obt_total_trackbacks)."</a>";
ELSE{
	IF ($post->ping_status == "open") echo "<img src=\"".get_bloginfo("template_directory")."/images/social-trackbacks.gif\" width=\"14\" height=\"14\" alt=\"No hay trackbacks\" />".obt_translate("No trackbacks");
	ELSE echo "<img src=\"".get_bloginfo("template_directory")."/images/social-trackbacks.gif\" width=\"14\" height=\"14\" alt=\"Trackbacks deshabilitados\" />".obt_translate("Trackbacks disabled");
};
echo "</li>\n";
echo "</ul>\n";
echo "						</div>\n";
echo "					</div>\n";
echo "<div class=\"clearer\"></div>\n";
include(TEMPLATEPATH."/ads/after-post-share-buttons.php");
?>