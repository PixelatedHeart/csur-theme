<?php
echo "		</div></div>\n";
echo "		<div class=\"sidebar\">\n";
echo "			<div class=\"sidebar-content clear\">\n";
include(TEMPLATEPATH."/ads/before-sidebar-main.php");
IF (!function_exists("dynamic_sidebar") || !dynamic_sidebar(obt_translate("Sidebar - Main"))){
	obt_widget_where();
	obt_widget_admin();
	obt_widget_login();
};
include(TEMPLATEPATH."/ads/after-sidebar-main.php");
echo "			</div>\n";
echo "			<div class=\"sidebar-left\"><div class=\"sidebar-content\">\n";
include(TEMPLATEPATH."/ads/before-sidebar-left.php");
IF (!function_exists("dynamic_sidebar") || !dynamic_sidebar(obt_translate("Sidebar - Left"))){
	IF (obt_get_themeoption("menu") == "regular") obt_widget_pages();
	obt_widget_search();
	obt_widget_tags();
	obt_widget_favorites();
	obt_widget_themeswitcher();
};
include(TEMPLATEPATH."/ads/after-sidebar-left.php");
echo "			</div></div>\n";
echo "			<div class=\"sidebar-right\"><div class=\"sidebar-content\">\n";
include(TEMPLATEPATH."/ads/before-sidebar-right.php");
IF (!function_exists("dynamic_sidebar") || !dynamic_sidebar(obt_translate("Sidebar - Right"))){
	obt_widget_subscribe();
	obt_widget_categories();
	obt_widget_bloggers();
	obt_widget_archives();
};
include(TEMPLATEPATH."/ads/after-sidebar-right.php");
echo "			</div></div>\n";
echo "		</div>\n";
echo "<div class=\"clear\"></div>\n";
include(TEMPLATEPATH."/ads/before-footer.php");
echo "	</div></div>\n";
?>
