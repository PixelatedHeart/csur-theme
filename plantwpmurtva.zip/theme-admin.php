<?php
FUNCTION obt_add_image_size($text){
	$text = stripslashes($text);
	$text = preg_replace_callback("'<img([^>]*?)src=([\"\'])([^>]*?)[\"\']([^>]*?)(\/?)>'i","obt_add_image_size_attributes",$text);
	$text = addslashes($text);
	RETURN $text;
};
FUNCTION obt_add_image_size_attributes($matches){
	$url = $matches[3];
	$attributes = $matches[1].$matches[4];
	$quote = $matches[2];
	$tag = "<img src={$quote}{$url}{$quote}";
	IF (preg_match("'width=[\"\'?]([0-9]*?)[\"\'?]'",$attributes,$matches)) $image_width = $matches[1];
	IF (preg_match("'height=[\"\'?]([0-9]*?)[\"\'?]'",$attributes,$matches)) $image_height = $matches[1];
	IF (preg_match("'alt=[\"\'](.*?)[\"\']'",$attributes,$matches)) $alt = $matches[1];
	IF (preg_match("'title=[\"\'](.*?)[\"\']'",$attributes,$matches)) $title = $matches[1];
	$new_alt = basename($url);
	$new_alt = str_replace(".thumbnail","",$new_alt);
	$new_alt = explode(".",$new_alt);
	array_pop($new_alt);
	$new_alt = implode(".",$new_alt);
	$new_alt = ucwords(str_replace(array("_","-",".")," ",$new_alt));
	IF (strlen($title) == 0) $attributes = " title={$quote}{$new_alt}{$quote} ".$attributes;
	ELSEIF ($title == basename($url) || $title == str_replace(".thumbnail","",basename($url))) $attributes = preg_replace("'title=([\"\'])(.*?)([\"\'])'","title=\\1{$new_alt}\\3",$attributes);
	IF (strlen($alt) == 0) $attributes = " alt={$quote}{$new_alt}{$quote} ".$attributes;
	ELSEIF ($alt == basename($url) || $alt == str_replace(".thumbnail","",basename($url))) $attributes = preg_replace("'alt=([\"\'])(.*?)([\"\'])'","alt=\\1{$new_alt}\\3",$attributes);
	IF (!$image_width || !$image_height){
		IF (function_exists("getimagesize")){
			IF (strpos($url,get_option("siteurl")) === 0){
				$file = substr($url,strlen(get_option("siteurl")));
				IF (substr($file,0,1) == "/") $file = substr($file,1);
				$abspath = ABSPATH;
				$abspath = str_replace("\\","/",$abspath);
				IF (substr($abspath,-1) == "/") $abspath = substr($abspath,0,-1);
				$image = $abspath."/".$file;
				$image_size = @getimagesize($image);
				IF (is_array($image_size)) IF ($image_size[0]){
					IF ($image_width){
						$image_size[1] = round($image_width * ($image_size[1] / $image_size[0]));
						$image_size[0] = $image_width;
					};
					IF ($image_height){
						$image_size[0] = round($image_height * ($image_size[0] / $image_size[1]));
						$image_size[1] = $image_height;
					};
					IF (!$image_height) $attributes = " height={$quote}{$image_size[1]}{$quote} ".$attributes;
					ELSE $tag = preg_replace("'height=([\"\'?])([0-9]*?)([\"\'?])'","'height={$quote}{$image_size[1]}{$quote}",$tag);
					IF (!$image_width) $attributes = " width={$quote}{$image_size[0]}{$quote} ".$attributes;
					ELSE $tag = preg_replace("'width=([\"\'?])([0-9]*?)([\"\'?])'","'width={$quote}{$image_size[0]}{$quote}",$tag);
				};
			};
		};
	};
	$tag .= "{$attributes} />";
	WHILE (strpos($tag,"  ") !== false) $tag = str_replace("  "," ",$tag);
	RETURN $tag;
};
add_filter("content_save_pre","obt_add_image_size");
FUNCTION obt_fix_slug($slug){
	IF (!strlen($slug)){
		$slug = $_POST["post_title"];
		$slug = str_replace(array("<",">"),"",$slug);
		$slug = str_replace(array(":",".",",","/","\\")," ",$slug);
		$slug = sanitize_title($slug);
		IF (strlen($slug)){
			$slug = apply_filters("name_save_pre",$slug);
			$slug = preg_replace("'(%..)'"," ",$slug);
			$slug = str_replace("-"," ",$slug);
			$slug = trim($slug);
			WHILE (strpos($slug,"  ") !== false) $slug = str_replace("  "," ",$slug);
			$slug = str_replace(" ","-",$slug);
		};
	};
	RETURN $slug;
};
add_filter("name_save_pre","obt_fix_slug");
FUNCTION obt_thumbnail_size($size,$attachment,$file) {
	$width = (obt_get_themeoption("thumbnail-width")*1)? obt_get_themeoption("thumbnail-width")*1 : 250;
	IF (!strlen($file) || !function_exists("getimagesize")) RETURN $width;
	$image_size = @getimagesize($file);
	IF (!is_array($image_size)) RETURN $width;
	IF (!$image_size[0]) RETURN $width;
	IF ($image_size[0] >= $image_size[1]) RETURN $width;
	ELSE RETURN round(($image_size[1] / $image_size[0]) * $width);
};
add_filter("wp_thumbnail_max_side_length","obt_thumbnail_size",10,3);
?>