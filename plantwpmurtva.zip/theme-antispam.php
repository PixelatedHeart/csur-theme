<?php
IF ($_SERVER["REQUEST_METHOD"] == "POST"){
	$obt_file_name = basename($_SERVER["SCRIPT_FILENAME"]);
	$obt_is_comment_form = $obt_is_send_form = $obt_is_contact_form = false;
	$obt_is_comment_form = ($obt_file_name == "wp-comments-post.php");
	$obt_is_send_form = ($obt_file_name == "index.php" && isset($_POST["send-name"]));
	$obt_is_contact_form = ($obt_file_name == "index.php" && isset($_POST["contact-name"]));
	IF ($obt_is_comment_form || $obt_is_send_form){
		$obt_is_spam = false;
		IF (!strlen($_POST["obt_time"]) || !strlen($_POST["obt_hash"])) $obt_is_spam = true;
		$obt_time = time();
		IF ($_POST["obt_time"] > $obt_time || $_POST["obt_time"] < $obt_time - 60*60*24) $obt_is_spam = true;
		$obt_hash = md5($_POST["obt_time"]."/".$_SERVER["SERVER_SOFTWARE"]);
		IF ($_POST["obt_hash"] != $obt_hash) $obt_is_spam = true;
		IF ($obt_is_spam){
			IF ($obt_is_comment_form) DIE(obt_translate("The comment could include spam and hasn't been saved"));
			ELSE DIE(obt_translate("The email could include spam and hasn't been delivered"));
		};
	};
};
?>