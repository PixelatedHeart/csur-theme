<?php
IF (!function_exists("get_comment")){
	FUNCTION &get_comment(&$comment,$output = OBJECT){
		global $comment_cache, $wpdb;
		IF (empty($comment)) RETURN null;
		IF (is_object($comment)){
			IF (!isset($comment_cache[$comment->comment_ID])) $comment_cache[$comment->comment_ID] = &$comment;
			$_comment = & $comment_cache[$comment->comment_ID];
		}ELSE{
			$comment = (int) $comment;
			IF (!isset($comment_cache[$comment])){
				$_comment = $wpdb->get_row("SELECT * FROM {$wpdb->comments} WHERE comment_ID = '{$comment}' LIMIT 1");
				$comment_cache[$comment->comment_ID] = & $_comment;
			}ELSE $_comment = & $comment_cache[$comment];
		};
	
		IF ($output == OBJECT) RETURN $_comment;
		ELSEIF ($output == ARRAY_A) RETURN get_object_vars($_comment);
		ELSEIF ($output == ARRAY_N) RETURN array_values(get_object_vars($_comment));
		ELSE RETURN $_comment;
	};
};
IF (!function_exists("get_post")){
	FUNCTION get_post($postid){
		global $post, $wpdb;
	 	IF ($postid == $post->ID) $a_post = $post;
	 	ELSE $a_post = $wpdb->get_row("SELECT * FROM {$wpdb->posts} WHERE ID = '{$postid}'");
	 	RETURN $a_post;
	};
};

FUNCTION obt_notify_comment($comment,$notification_emails){
	unset($notification_emails[$comment->comment_author_email]);
	FOREACH ($notification_emails as $email=>$name) IF (!strlen($name)) unset($notification_emails[$email]);
	IF (count($notification_emails)){
		$post = get_post($comment->comment_post_ID);
		$subject = obt_html_decode(obt_translate("New comment on %1",$post->post_title));
		$message = "{$subject}\n";
		$message .= get_permalink($post->ID)."#".obt_translate("comment")."-{$comment->comment_post_ID}\n\n";
		$message .= $comment->comment_author;
		IF (preg_match("!^http:\/\/(.*)\.(.*)$!",$comment->comment_author_url)) $message .= " ({$comment->comment_author_url})";
		$message .= ":\n";
		$comment->comment_content = preg_replace("'<[^>]*?>'si"," ",$comment->comment_content);
		WHILE (strpos($comment->comment_content,"  ") !== false) $comment->comment_content = str_replace("  "," ",$comment->comment_content);
		$comment->comment_content = trim($comment->comment_content);
		$message .= $comment->comment_content;
		$message .= "\n\n--\n".get_bloginfo("name")."\n".get_option("home");
		$headers .= "From: ".get_bloginfo("name")." <no-reply@".preg_replace("'^www\.'","",strtolower($_SERVER["HTTP_HOST"])).">\n";
		$headers .= "Message-ID: <".md5(time())."@".preg_replace("'^www\.'","",strtolower($_SERVER["HTTP_HOST"])).">\n";
		$headers .= "X-Mailer: PHP version ".phpversion()."\n";
		$headers .= "MIME-Version: 1.0\n";
		$headers .= "Content-type: text/plain; charset=\"".get_option("blog_charset")."\"\n";
		@set_time_limit(0);
		@ini_set("sendmail_from",$email);
		FOREACH ($notification_emails as $email=>$name) @mail("{$name} <{$email}>",$subject,$message,$headers);
		@ini_restore("sendmail_from");
	};
};
FUNCTION obt_comment_post($id,$status=""){
	global $wpdb;
	$comment = get_comment($id);
	$meta_exists = false;
	IF ($notification_emails = $wpdb->get_var("SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = '{$comment->comment_post_ID}' AND meta_key = 'comment-notification'")) $meta_exists = true;
	$notification_emails = unserialize($notification_emails);
	IF (strlen($comment->comment_author_email)){
		$comment_author = (strlen($comment->comment_author))? $comment->comment_author : obt_translate("Anonymous");
		$notify = ($_POST["notifyme"])? $comment_author : "";
		$update_meta = false;
		IF (!is_array($notification_emails)) $notification_emails = array();
		IF (isset($notification_emails[$comment->comment_author_email])){
			IF ($notification_emails[$comment->comment_author_email] != $notify){
				$notification_emails[$comment->comment_author_email] = $notify;
				$update_meta = true;
			};
		}ELSE $update_meta = true;
		$notification_emails[$comment->comment_author_email] = $notify;
		IF ($update_meta){
			IF ($meta_exists) $wpdb->query("UPDATE {$wpdb->postmeta} SET meta_value = '".serialize($notification_emails)."' WHERE post_id = '{$comment->comment_post_ID}' AND meta_key = 'comment-notification'");
			ELSE $wpdb->query("INSERT INTO {$wpdb->postmeta} (post_id,meta_key,meta_value) VALUES ('{$comment->comment_post_ID}','comment-notification','".serialize($notification_emails)."')");
		};
	};
	IF ($status == "1" || $status === "approve" || $comment->comment_approved == "1") obt_notify_comment($comment,$notification_emails);
};
FUNCTION obt_set_comment_status($id,$status=""){
	global $wpdb;
	$comment = get_comment($id);
	IF ($status == "1" || $status === "approve" || $comment->comment_approved == "1"){
		$notification_emails = $wpdb->get_var("SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = '{$comment->comment_post_ID}' AND meta_key = 'comment-notification'");
		$notification_emails = unserialize($notification_emails);
		IF (!is_array($notification_emails)) $notification_emails = array();
		obt_notify_comment($comment,$notification_emails);
	};
};
IF (function_exists("add_action") && obt_get_themeoption("comment-notification")){
	add_action("comment_post","obt_comment_post",10,2);
	add_action("wp_set_comment_status","obt_set_comment_status",10,2);
};
?>