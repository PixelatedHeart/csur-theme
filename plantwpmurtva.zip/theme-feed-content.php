<?php
FUNCTION obt_fix_comment_links(){
	IF (is_feed() && !is_404()){
		ob_start("obt_fix_comment_links_handler");
	};
};
FUNCTION obt_fix_comment_links_handler($text){
	IF (obt_translate("comments") != "comments") $text = str_replace("#comments</comments>","#".obt_translate("comments")."</comments>",$text);
	IF (obt_translate("comment") != "comment"){
		global $feed;
		$self = basename($_SERVER["PHP_SELF"]);
		IF ($self == "wp-rss2.php" || $self == "wp-commentsrss2.php" || $feed == "feed" || $feed == "rss2"){
			$text = preg_replace("'#comment-([0-9]+)</link>'","#".obt_translate("comment")."-\\1</link>",$text);
			$text = preg_replace("'#comment-([0-9]+)</guid>'","#".obt_translate("comment")."-\\1</guid>",$text);
		}ELSEIF ($self == "wp-atom.php" || $feed == "atom"){
			$text = preg_replace("'#comment-([0-9]+)</id>'","#".obt_translate("comment")."-\\1</id>",$text);
			$text = preg_replace("'#comment-([0-9]+)\" type=\"text/html\" />'","#".obt_translate("comment")."-\\1\" type=\"text/html\" />",$text);
			$text = preg_replace("'#comment-([0-9]+)\">'","#".obt_translate("comment")."-\\1\">",$text);
		};
	};
	RETURN $text;
};
add_action("template_redirect","obt_fix_comment_links");
FUNCTION obt_the_content_rss($text){
	IF (is_feed() && !is_404()){
		global $post;
		IF (strlen($post->post_password)){
			$text = "<form action=\"".get_option("siteurl")."/wp-pass.php\" method=\"post\">\n";
			$text .= "<p>".obt_translate("This post is password-protected").":</p>\n";
			$text .= "<p>\n";
			$text .= "<label for=\"post_password\"><input type=\"password\" name=\"post_password\" id=\"post_password\" size=\"20\" class=\"text\" style=\"width:120px\" /></label> ";
			$text .= "<input name=\"submit\" type=\"submit\" value=\"".obt_translate("Submit")."\" class=\"button\" />\n";
			$text .= "</p>\n";
			$text .= "</form>\n";
		};
		IF (obt_get_themeoption("feed-content-related-posts")){
			$related_posts = obt_related_posts($post->post_date_gmt);
			IF (count($related_posts)){
				$text .= "<p>\n";
				$text .= "<strong>".obt_translate("Related posts")."</strong>:\n";
				FOREACH ($related_posts as $related_post){
					$related_post_title = apply_filters("the_title",$related_post->post_title);
					IF (!strlen($related_post_title)) $related_post_title = translate("Untitled");
					$related_post_title = wp_specialchars($related_post_title,true);
					$text .= "<br /><a href=\"".get_permalink($related_post->ID)."\" title=\"".obt_translate("Permanent link to this post")."\">{$related_post_title}</a>\n";
				};
				$text .= "</p>\n";
			};
		};
		IF (obt_get_themeoption("feed-content-categories") || (obt_get_themeoption("feed-content-tags") && (function_exists("the_tags") || function_exists("UTW_ShowTagsForCurrentPost") || function_exists("STP_GetPostTags")))){
			$text .= "<p>\n";
			IF (obt_get_themeoption("feed-content-categories")){
				$text .= "<strong>".obt_translate("Categories")."</strong>: ";
				IF ($categories = get_the_category($post->ID)){
					usort($categories,"obt_sort_categories");
					$comma = false;
					FOREACH ($categories as $category){
						IF ($comma) $text .= ", ";
						$comma = true;
						$category_link = get_category_link($category->cat_ID);
						$category_feed = get_category_rss_link(false,$category->cat_ID,$category->category_nicename);
						$category_link = obt_fix_link($category_link);
						$category_feed = obt_fix_feed_link($category_feed,$category_link);
						$text .= "<a href=\"{$category_link}\" title=\"".obt_translate("View all posts under the category %1","&laquo;".wp_specialchars($category->cat_name,true)."&raquo;")."\">".wp_specialchars($category->cat_name,true)."</a>";
					};
					unset($categories);
				}ELSE $text .= obt_translate("No categories");
				$text .= ".";
			};
			IF (obt_get_themeoption("feed-content-tags")){
				IF (function_exists("get_the_tags")){
					IF ($tags = get_the_tags($post->ID)){
						IF (obt_get_themeoption("feed-content-categories")) $text .= "\n<br />";
						$text .= "<strong>".obt_translate("Tags")."</strong>: ";
						usort($tags,"obt_sort_tags");
						$comma = false;
						FOREACH ($tags as $tag){
							IF ($comma) $text .= ", ";
							$comma = true;
							$tag_name = wp_specialchars($tag->name,true);
							$tag_link = get_tag_link($tag->term_id);
							$tag_feed = obt_tag_feed($tag_link);
							$tag_link = obt_fix_link($tag_link);
							$tag_feed = obt_fix_feed_link($tag_feed,$tag_link);
							$text .= "<a href=\"{$tag_link}\" title=\"".obt_translate("View all posts tagged %1","&laquo;{$tag_name}&raquo;")."\" rel=\"tag\">{$tag_name}</a>";
						};
						unset($tags);
						$text .= ".";
					};
				}ELSEIF (function_exists("UTW_ShowTagsForCurrentPost")){
					global $utw, $baseurl, $home, $siteurl, $prettyurls;
					flush();
					$tags = $utw->GetTagsForPost($post->ID);
					IF (count($tags)){
						IF (obt_get_themeoption("feed-content-categories")) $text .= "\n<br />";
						$text .= "<strong>".obt_translate("Tags")."</strong>: ";
						$comma = false;
						FOREACH ($tags as $tag){
							IF ($comma) $text .= ", ";
							$comma = true;
							$tag_name = str_replace("_"," ",$tag->tag);
							$tag_name = str_replace("-"," ",$tag_name);
							$tag_name = stripslashes($tag_name);
							$tag_name = wp_specialchars($tag_name);
							$tag_name_url = urlencode(stripslashes(strtolower($tag->tag)));
							IF ($prettyurls == "yes"){
								$tag_link = "{$home}{$baseurl}{$tag_name_url}/";
								$tag_feed = "{$tag_link}feed/";
							}ELSE{
								$tag_link = "$home/index.php?tag={$tag_name_url}";
								$tag_feed = "{$tag_link}&amp;feed=rss";
							};
							$text .= "<a href=\"{$tag_link}\" title=\"".obt_translate("View all posts tagged %1","&laquo;{$tag_name}&raquo;")."\" rel=\"tag\">{$tag_name}</a>";
						};
						unset($tags);
						$text .= ".";
					};
				}ELSEIF (function_exists("STP_GetPostTags")){
					global $STagging;
					flush();
					$tags = $STagging->getPostTags($post->ID);
					IF (count($tags)){
						IF (obt_get_themeoption("feed-content-categories")) $text .= "\n<br />";
						$text .= "<strong>".obt_translate("Tags")."</strong>: ";
						$comma = false;
						FOREACH ($tags as $tag){
							IF ($comma) $text .= ", ";
							$comma = true;
							$tag_link = $STagging->getTagPermalink($tag);
							$tag_feed = obt_tag_feed($tag_link);
							$tag_link = obt_fix_link($tag_link);
							$tag_feed = obt_fix_feed_link($tag_feed,$tag_link);
							$tag_name = wp_specialchars($tag);
							$text .= "<a href=\"{$tag_link}\" title=\"".obt_translate("View all posts tagged %1","&laquo;{$tag_name}&raquo;")."\" rel=\"tag\">{$tag_name}</a>";
						};
						unset($tags);
						$text .= ".";
					};
				};
			};
			$text .= "\n</p>\n";
		};
		IF (obt_get_themeoption("feed-content-share")){
			$text .= "<p>\n";
			$text .= "<strong>".obt_translate("Share this post")."</strong>:";
			IF (obt_get_themeoption("share-barrapunto")) $text .= "<br />\n<img src=\"".get_bloginfo("template_directory")."/images/social-barrapunto.gif\" width=\"14\" height=\"14\" align=\"absbottom\" alt=\"".obt_translate("Submit this post to %1","Barrapunto")."\" /> <a href=\"http://barrapunto.com/submit.pl?story=".urlencode(obt_translate("I've just read on the blog %1 the post %2","<a href=\"".get_option("home")."/\">".get_bloginfo("name")."</a>","<a href=\"".get_permalink()."\">{$post->post_title}</a>")."...")."&amp;subj=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Submit this post to %1","Barrapunto")."\">Barrapunto</a>";
			IF (obt_get_themeoption("share-blinklist")) $text .= "<br />\n<img src=\"".get_bloginfo("template_directory")."/images/social-blinklist.gif\" width=\"14\" height=\"14\" align=\"absbottom\" alt=\"".obt_translate("Add this post to %1","BlinkList")."\" /> <a href=\"http://www.blinklist.com/index.php?Action=Blink/addblink.php&amp;Description=&amp;Url=".urlencode(get_permalink())."&amp;Title=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Add this post to %1","BlinkList")."\">BlinkList</a>";
			IF (obt_get_themeoption("share-blogmemes")) $text .= "<br />\n<img src=\"".get_bloginfo("template_directory")."/images/social-blogmemes.gif\" width=\"14\" height=\"14\" align=\"absbottom\" alt=\"".obt_translate("Submit this post to %1","BlogMemes")."\" /> <a href=\"http://www.blogmemes.com/post.php?url=".urlencode(get_permalink())."&amp;title=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Submit this post to %1","BlogMemes")."\">BlogMemes</a>";
			IF (obt_get_themeoption("share-corank")) $text .= "<br />\n<img src=\"".get_bloginfo("template_directory")."/images/social-corank.gif\" width=\"14\" height=\"14\" align=\"absbottom\" alt=\"".obt_translate("Submit this post to %1","CoRank")."\" /> <a href=\"http://www.corank.com/submit?url=".urlencode(get_permalink())."&amp;title=".urlencode($post->post_title)."&amp;source=w\" rel=\"nofollow\" title=\"".obt_translate("Submit this post to %1","CoRank")."\">CoRank</a>";
			IF (obt_get_themeoption("share-corank-es")) $text .= "<br />\n<img src=\"".get_bloginfo("template_directory")."/images/social-corank.gif\" width=\"14\" height=\"14\" align=\"absbottom\" alt=\"".obt_translate("Submit this post to %1","CoRank Espa&ntilde;ol")."\" /> <a href=\"http://es.corank.com/submit?url=".urlencode(get_permalink())."&amp;title=".urlencode($post->post_title)."&amp;source=w\" rel=\"nofollow\" title=\"".obt_translate("Submit this post to %1","CoRank Espa&ntilde;ol")."\">CoRank Espa&ntilde;ol</a>";
			IF (obt_get_themeoption("share-delicious")) $text .= "<br />\n<img src=\"".get_bloginfo("template_directory")."/images/social-delicious.gif\" width=\"14\" height=\"14\" align=\"absbottom\" alt=\"".obt_translate("Add this post to %1","Delicious")."\" /> <a href=\"http://del.icio.us/post?url=".urlencode(get_permalink())."&amp;title=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Add this post to %1","Delicious")."\">Delicious</a>";
			IF (obt_get_themeoption("share-digg")) $text .= "<br />\n<img src=\"".get_bloginfo("template_directory")."/images/social-digg.gif\" width=\"14\" height=\"14\" align=\"absbottom\" alt=\"".obt_translate("Submit this post to %1","Digg")."\" /> <a href=\"http://digg.com/submit?phase=2&url=".urlencode(get_permalink())."&amp;title=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Submit this post to %1","Digg")."\">Digg</a>";
			IF (obt_get_themeoption("share-enchilame")) $text .= "<br />\n<img src=\"".get_bloginfo("template_directory")."/images/social-enchilame.gif\" width=\"14\" height=\"14\" align=\"absbottom\" alt=\"".obt_translate("Submit this post to %1","Ench&iacute;lame")."\" /> <a href=\"http://www.enchilame.com/submit.php?url=".urlencode(get_permalink())."\" rel=\"nofollow\" title=\"".obt_translate("Submit this post to %1","Ench&iacute;lame")."\">Ench&iacute;lame</a>";
			IF (obt_get_themeoption("share-fark")) $text .= "<br />\n<img src=\"".get_bloginfo("template_directory")."/images/social-fark.gif\" width=\"14\" height=\"14\" align=\"absbottom\" alt=\"".obt_translate("Submit this post to %1","Fark")."\" /> <a href=\"http://cgi.fark.com/cgi/fark/edit.pl?new_url=".urlencode(get_permalink())."&amp;new_comment=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Submit this post to %1","Fark")."\">Fark</a>";
			IF (obt_get_themeoption("share-fresqui-act")) $text .= "<br />\n<img src=\"".get_bloginfo("template_directory")."/images/social-fresqui.gif\" width=\"14\" height=\"14\" align=\"absbottom\" alt=\"".obt_translate("Submit this post to %1","Fresqui Actualidad")."\" /> <a href=\"http://act.fresqui.com/post?url=".urlencode(get_permalink())."&amp;title=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Submit this post to %1","Fresqui Actualidad")."\">Fresqui Actualidad</a>";
			IF (obt_get_themeoption("share-fresqui-ocio")) $text .= "<br />\n<img src=\"".get_bloginfo("template_directory")."/images/social-fresqui.gif\" width=\"14\" height=\"14\" align=\"absbottom\" alt=\"".obt_translate("Submit this post to %1","Fresqui Ocio")."\" /> <a href=\"http://ocio.fresqui.com/post?url=".urlencode(get_permalink())."&amp;title=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Submit this post to %1","Fresqui Ocio")."\">Fresqui Ocio</a>";
			IF (obt_get_themeoption("share-fresqui-tec")) $text .= "<br />\n<img src=\"".get_bloginfo("template_directory")."/images/social-fresqui.gif\" width=\"14\" height=\"14\" align=\"absbottom\" alt=\"".obt_translate("Submit this post to %1","Fresqui Tecnolog&iacute;a")."\" /> <a href=\"http://tec.fresqui.com/post?url=".urlencode(get_permalink())."&amp;title=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Submit this post to %1","Fresqui Tecnolog&iacute;a")."\">Fresqui Tecnolog&iacute;a</a>";
			IF (obt_get_themeoption("share-furl")) $text .= "<br />\n<img src=\"".get_bloginfo("template_directory")."/images/social-furl.gif\" width=\"14\" height=\"14\" align=\"absbottom\" alt=\"".obt_translate("Add this post to %1","Furl")."\" /> <a href=\"http://furl.net/storeIt.jsp?u=".urlencode(get_permalink())."&amp;t=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Add this post to %1","Furl")."\">Furl</a>";
			IF (obt_get_themeoption("share-google")) $text .= "<br />\n<img src=\"".get_bloginfo("template_directory")."/images/social-google.gif\" width=\"14\" height=\"14\" align=\"absbottom\" alt=\"".obt_translate("Add this post to %1","Google Bookmarks")."\" /> <a href=\"http://www.google.com/bookmarks/mark?op=edit&bkmk=".urlencode(get_permalink())."&amp;title=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Add this post to %1","Google Bookmarks")."\">Google Bookmarks</a>";
			IF (obt_get_themeoption("share-live")) $text .= "<br />\n<img src=\"".get_bloginfo("template_directory")."/images/social-live.gif\" width=\"14\" height=\"14\" align=\"absbottom\" alt=\"".obt_translate("Add this post to %1","Live Favorites")."\" /> <a href=\"https://favorites.live.com/quickadd.aspx?marklet=1&mkt=es-es&url=".urlencode(get_permalink())."&amp;title=".urlencode($post->post_title)."&amp;top=1\" rel=\"nofollow\" title=\"".obt_translate("Add this post to %1","Live Favorites")."\">Live Favorites</a>";
			IF (obt_get_themeoption("share-magnolia")) $text .= "<br />\n<img src=\"".get_bloginfo("template_directory")."/images/social-magnolia.gif\" width=\"14\" height=\"14\" align=\"absbottom\" alt=\"".obt_translate("Add this post to %1","Magnolia")."\" /> <a href=\"http://ma.gnolia.com/bookmarklet/add?url=".urlencode(get_permalink())."&amp;title=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Add this post to %1","Magnolia")."\">Magnolia</a>";
			IF (obt_get_themeoption("share-meneame")) $text .= "<br />\n<img src=\"".get_bloginfo("template_directory")."/images/social-meneame.gif\" width=\"14\" height=\"14\" align=\"absbottom\" alt=\"".obt_translate("Submit this post to %1","Men&eacute;ame")."\" /> <a href=\"http://meneame.net/submit.php?url=".urlencode(get_permalink())."\" rel=\"nofollow\" title=\"".obt_translate("Submit this post to %1","Men&eacute;ame")."\">Men&eacute;ame</a>";
			IF (obt_get_themeoption("share-neodiario")) $text .= "<br />\n<img src=\"".get_bloginfo("template_directory")."/images/social-neodiario.gif\" width=\"14\" height=\"14\" align=\"absbottom\" alt=\"".obt_translate("Submit this post to %1","Neodiario")."\" /> <a href=\"http://www.neodiario.net/submit.php?url=".urlencode(get_permalink())."&amp;title=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Submit this post to %1","Neodiario")."\">Neodiario</a>";
			IF (obt_get_themeoption("share-netscape")) $text .= "<br />\n<img src=\"".get_bloginfo("template_directory")."/images/social-netscape.gif\" width=\"14\" height=\"14\" align=\"absbottom\" alt=\"".obt_translate("Submit this post to %1","Netscape")."\" /> <a href=\"http://www.netscape.com/submit/?U=".urlencode(get_permalink())."&amp;T=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Submit this post to %1","Netscape")."\">Netscape</a>";
			IF (obt_get_themeoption("share-newsvine")) $text .= "<br />\n<img src=\"".get_bloginfo("template_directory")."/images/social-newsvine.gif\" width=\"14\" height=\"14\" align=\"absbottom\" alt=\"".obt_translate("Submit this post to %1","Newsvine")."\" /> <a href=\"http://www.newsvine.com/_wine/save?u=".urlencode(get_permalink())."&amp;h=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Submit this post to %1","Newsvine")."\">Newsvine</a>";
			IF (obt_get_themeoption("share-reddit")) $text .= "<br />\n<img src=\"".get_bloginfo("template_directory")."/images/social-reddit.gif\" width=\"14\" height=\"14\" align=\"absbottom\" alt=\"".obt_translate("Submit this post to %1","Reddit")."\" /> <a href=\"http://reddit.com/submit?url=".urlencode(get_permalink())."&amp;title=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Submit this post to %1","Reddit")."\">Reddit</a>";
			IF (obt_get_themeoption("share-rojo")) $text .= "<br />\n<img src=\"".get_bloginfo("template_directory")."/images/social-rojo.gif\" width=\"14\" height=\"14\" align=\"absbottom\" alt=\"".obt_translate("Submit this post to %1","Rojo")."\" /> <a href=\"http://www.rojo.com/submit/?url=".urlencode(get_permalink())."&amp;title=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Submit this post to %1","Rojo")."\">Rojo</a>";
			IF (obt_get_themeoption("share-slashdot")) $text .= "<br />\n<img src=\"".get_bloginfo("template_directory")."/images/social-slashdot.gif\" width=\"14\" height=\"14\" align=\"absbottom\" alt=\"".obt_translate("Submit this post to %1","Slashdot")."\" /> <a href=\"http://slashdot.org/bookmark.pl?url=".urlencode(get_permalink())."&amp;title=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Submit this post to %1","Slashdot")."\">Slashdot</a>";
			IF (obt_get_themeoption("share-spurl")) $text .= "<br />\n<img src=\"".get_bloginfo("template_directory")."/images/social-spurl.gif\" width=\"14\" height=\"14\" align=\"absbottom\" alt=\"".obt_translate("Add this post to %1","Spurl")."\" /> <a href=\"http://www.spurl.net/spurl.php?url=".urlencode(get_permalink())."&amp;title=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Add this post to %1","Spurl")."\">Spurl</a>";
			IF (obt_get_themeoption("share-stumbleupon")) $text .= "<br />\n<img src=\"".get_bloginfo("template_directory")."/images/social-stumbleupon.gif\" width=\"14\" height=\"14\" align=\"absbottom\" alt=\"".obt_translate("Submit this post to %1","Stumbleupon")."\" /> <a href=\"http://www.stumbleupon.com/submit?url=".urlencode(get_permalink())."&amp;title=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Submit this post to %1","Stumbleupon")."\">Stumbleupon</a>";
			IF (obt_get_themeoption("share-technorati")) $text .= "<br />\n<img src=\"".get_bloginfo("template_directory")."/images/social-technorati.gif\" width=\"14\" height=\"14\" align=\"absbottom\" alt=\"".obt_translate("Add this post to %1","Technorati Favorites")."\" /> <a href=\"http://www.technorati.com/faves?add=".urlencode(get_permalink())."\" rel=\"nofollow\" title=\"".obt_translate("Add this post to %1","Technorati Favorites")."\">Technorati Favorites</a>";
			IF (obt_get_themeoption("share-yahoo")) $text .= "<br />\n<img src=\"".get_bloginfo("template_directory")."/images/social-yahoo.gif\" width=\"14\" height=\"14\" align=\"absbottom\" alt=\"".obt_translate("Add this post to %1","Yahoo MyWeb")."\" /> <a href=\"http://myweb2.search.yahoo.com/myresults/bookmarklet?u=".urlencode(get_permalink())."&amp;t=".urlencode($post->post_title)."\" rel=\"nofollow\" title=\"".obt_translate("Add this post to %1","Yahoo MyWeb")."\">Yahoo MyWeb</a>";
			$text .= "\n</p>\n";
		};
		IF (obt_get_themeoption("feed-content-attribution")){
			$post_title = apply_filters("the_title",$post->post_title);
			IF (!strlen($post_title)) $post_title = translate("Untitled");
			$post_title = wp_specialchars($post_title,true);
			$text .= "<p><strong>".obt_translate("Permanent link")."</strong>: <a href=\"".get_permalink()."\">{$post_title}</a>";
			IF ($post->comment_status == "open") $text .= " (<a href=\"".get_permalink()."#".obt_translate("comments")."\"><strong>".obt_translate("Write a comment")."</strong></a>)";
			$text .= ".<br />\n";
			$text .= "<strong>".obt_translate("Read more")."</strong>: <a href=\"".get_option("home")."/\">".get_bloginfo("name")."</a>.</p>\n";
		};
	};
	RETURN $text;
};
add_filter("the_content","obt_the_content_rss");
add_filter("the_content_rss","obt_the_content_rss");
FUNCTION obt_the_title_rss($text){
	IF (is_feed() && !is_404()){
		$text = trim(str_replace(trim(sprintf(__("Protected: %s"),"")),"",$text));
		IF (!strlen($text)) $text = ent2ncr(obt_translate("Untitled"));
		IF (strlen($post->post_password)) $text = ent2ncr(obt_translate("%1 (protected)",$text));
	};
	RETURN $text;
};
add_filter("the_title","obt_the_title_rss");
add_filter("the_title_rss","obt_the_title_rss");
?>