<?php
FUNCTION obt_feed_init(){
	IF (is_feed() && !is_404()){
		global $feed, $withcomments, $wp_query;
		$self = basename($_SERVER["PHP_SELF"]);
		IF ($self == "wp-rss2.php" || $self == "wp-commentsrss2.php" || $feed == "feed" || $feed == "rss2"){
			IF (!obt_get_themeoption("feed-rss2")) obt_status_404();
		}ELSEIF ($self == "wp-rss.php" || $feed == "rss"){
			IF (!obt_get_themeoption("feed-rss")) obt_status_404();
		}ELSEIF ($self == "wp-atom.php" || $feed == "atom"){
			IF (!obt_get_themeoption("feed-atom")) obt_status_404();
		}ELSEIF ($self == "wp-rdf.php" || $feed == "rdf"){
			IF (!obt_get_themeoption("feed-rdf")) obt_status_404();
		};
		$feedburner = false;
		$feedburner_comments = false;
		IF (!preg_match("'feedburner|feedvalidator'i",$_SERVER["HTTP_USER_AGENT"])){
			IF (preg_match ("!^http:\/\/(.*)\.(.*)$!",obt_get_themeoption("alternate-feed"))){
				$domain = parse_url(obt_get_themeoption("alternate-feed"));
				$domain = $domain["host"];
				IF (strpos($domain,"feeds.feedburner.") === 0) $feedburner = true;
			};
			IF (preg_match ("!^http:\/\/(.*)\.(.*)$!",obt_get_themeoption("alternate-feed-comments"))){
				$domain = parse_url(obt_get_themeoption("alternate-feed-comments"));
				$domain = $domain["host"];
				IF (strpos($domain,"feeds.feedburner.") === 0) $feedburner_comments = true;
			};
		};
		IF (is_single() || is_page()){
			IF (!obt_get_themeoption("feed-single")) obt_status_404();
		}ELSEIF (is_category()){
			IF (!obt_get_themeoption("feed-categories")) obt_status_404();
		}ELSEIF (obt_is_tag()){
			IF (!obt_get_themeoption("feed-tags")) obt_status_404();
		}ELSEIF (is_author()){
			IF (!obt_get_themeoption("feed-bloggers")) obt_status_404();
		}ELSEIF (is_date() || is_search() || is_archive() ){
			obt_status_404();
		}ELSEIF ($withcomments){
			IF (!obt_get_themeoption("feed-comments")) obt_status_404();
			IF ($feedburner_comments) obt_status_301(obt_get_themeoption("alternate-feed-comments"));
		}ELSE{
			IF (!obt_get_themeoption("feed")) obt_status_404();
			IF ($feedburner) obt_status_301(obt_get_themeoption("alternate-feed"));
		};
	}; 
};
IF (function_exists("add_action")) add_action("template_redirect","obt_feed_init");
FUNCTION obt_feed_url($name){
	echo obt_get_feed_url($name);
};
FUNCTION obt_get_feed_url($name){
	IF ($name == "entries") RETURN (preg_match ("!^http:\/\/(.*)\.(.*)$!",obt_get_themeoption("alternate-feed")))? obt_get_themeoption("alternate-feed") : get_bloginfo("rss2_url");
	ELSEIF ($name == "comments") RETURN (preg_match ("!^http:\/\/(.*)\.(.*)$!",obt_get_themeoption("alternate-feed-comments")))? obt_get_themeoption("alternate-feed-comments") : get_bloginfo("comments_rss2_url");
};
FUNCTION obt_fix_feed_link($feed,$url){
	IF (get_option("permalink_structure")){
		IF (substr($url,-1) != "/") $url .= "/";
		$url .= "feed/";
	}ELSE $url = $feed;
	RETURN $url;
};
?>
