<?php
require_once(dirname(__FILE__)."/theme-translation.php");
require_once(dirname(__FILE__)."/theme-functions.php");
require_once(dirname(__FILE__)."/theme-toolkit.php");

$obt_script = <<<EOF
<script type="text/javascript">
<!--
function obtHsl2rgb(hue,saturation,luminance){
	if (saturation == 0) red = green = blue = luminance;
	else{
		hue = Math.round(100*hue/255)/100;
		saturation = Math.round(100*saturation/255)/100;
		luminance = Math.round(100*luminance/255)/100;

		if (luminance < 0.5) v2 = luminance*(1+saturation);
		else v2 = (luminance+saturation)-(saturation*luminance);

		v1 = 2*luminance-v2;
		red = 255*obtHue2rgb(v1,v2,hue+(1/3));
		green = 255*obtHue2rgb(v1,v2,hue);
		blue = 255*obtHue2rgb(v1,v2,hue-(1/3));
	};
	red = Math.round(red).toString(16);
	green = Math.round(green).toString(16);
	blue = Math.round(blue).toString(16);
	rgb = "#"+red+green+blue;
	return rgb.toLowerCase();
};
function obtHue2rgb(v1,v2,hue){
	if (hue < 0){ hue += 1; }
	if (hue > 1) hue -= 1;
	if ((6*hue) < 1) return (v1+(v2-v1)*6*hue);
	if ((2*hue) < 1) return (v2);
	if ((3*hue) < 2) return (v1+(v2-v1)*((2/3)-hue)*6);
	return (v1);
};
function obtPicker(name,type){
	if (document.getElementById){
		function obtUpdateSaturationPicker(hue){
			var saturationOldPick = document.getElementById(name+"saturationOldPick");
			if (saturationOldPick){
				var saturationNewPick = document.getElementById(name+"saturationNewPick");
				saturationNewPick.style.backgroundColor = saturationOldPick.style.backgroundColor = obtHsl2rgb(hue,saturationOldPick.innerHTML,150);
				for (var i = 1; i <= 255; i++){
					var color = document.getElementById(name+"saturationPicker"+i);
					color.style.backgroundColor = obtHsl2rgb(hue,i,150);
					color.style.color = obtHsl2rgb(hue,i,150);
				};
			};
		};
		var input = document.getElementById(name+type);
		if (input){
			input.style.cssText = "display:none";
			document.write("<div style=\"border:1px solid #b2b2b2;height:22px;margin-top:-20px;position:relative;width:339px\">&nbsp;");
			document.write("<div id=\""+name+type+"OldPick\" style=\"color:white;left:1px;position:absolute;font-size:12px;height:20px;line-height:20px;text-align:center;top:1px;width:40px\">&nbsp;</div>");
			document.write("<div id=\""+name+type+"NewPick\" style=\"color:white;left:42px;position:absolute;font-size:12px;height:20px;line-height:20px;text-align:center;top:1px;width:40px\">&nbsp;</div>");
			document.write("<div id=\""+name+type+"Picker\" style=\"cursor:crosshair;left:83px;position:absolute;top:1px\"></div>");
			document.write("</div>");
			var oldPick = document.getElementById(name+type+"OldPick")
			var newPick = document.getElementById(name+type+"NewPick")
			var picker = document.getElementById(name+type+"Picker")
			if (document.createElement){
				var hue = document.getElementById(name+"hue").value;
				for (var i = 1; i <= 255; i++){
					var color = document.createElement("SPAN");
					color.id = name+type+"Picker"+i;
					var rgb = (type == "hue")? obtHsl2rgb(i,200,150) : obtHsl2rgb(hue,i,150);
					if (color.style){
						color.style.cssText = "background:"+rgb+";color:"+rgb+";float:left;height:20px;overflow:hidden;width:1px";
						color.innerHTML = i;
						color.onmouseover = function(){
							hue = (type == "hue")? this.innerHTML: document.getElementById(name+"hue").value;
							saturation = (type == "hue")? 200 : saturation = this.innerHTML;
							newPick.innerHTML = this.innerHTML;
							newPick.style.backgroundColor = obtHsl2rgb(hue,saturation,150);
						};
						color.onmouseout = function(){
							newPick.innerHTML = "";
							newPick.style.backgroundColor = oldPick.style.backgroundColor;
						};
						color.onclick = function(){
							hue = (type == "hue")? this.innerHTML: document.getElementById(name+"hue").value;
							saturation = (type == "hue")? 200 : saturation = this.innerHTML;
							input.value = this.innerHTML;
							oldPick.innerHTML = this.innerHTML;
							oldPick.style.backgroundColor = obtHsl2rgb(hue,saturation,150);
							if (type == "hue") obtUpdateSaturationPicker(this.innerHTML);
						};
						picker.appendChild(color);
					};
				};
				if (newPick.style){
					var rgb = (type == "hue")? obtHsl2rgb(input.value,200,150) : obtHsl2rgb(hue,input.value,150);
					newPick.style.backgroundColor = oldPick.style.backgroundColor = rgb;
					newPick.innerHTML = "";
					oldPick.innerHTML = input.value;
				};
			};
		};
	};
};
//-->
</script>
EOF;

IF (function_exists("themetoolkit")){
	$theme_options["link-separator"] = "{$obt_script}".obt_translate("Links")." ## separator";
	$theme_options["linkhue"] = obt_translate("Color")." ## ## <script type=\"text/javascript\"><!--//\nobtPicker(\"link\",\"hue\");\n//--></script>";
	$theme_options["linksaturation"] = obt_translate("Intensity")." ## ## <script type=\"text/javascript\"><!--//\nobtPicker(\"link\",\"saturation\");\n//--></script>";
	
	$theme_options["header-separator"] = obt_translate("Header and footer")." ## separator";
	$theme_options["headerhue"] = obt_translate("Color")." ## ## <script type=\"text/javascript\"><!--//\nobtPicker(\"header\",\"hue\");\n//--></script>";
	$theme_options["headersaturation"] = obt_translate("Intensity")." ## ## <script type=\"text/javascript\"><!--//\nobtPicker(\"header\",\"saturation\");\n//--></script>";
	
	$theme_options["colors-separator"] = obt_translate("Colors")." ## separator";
	$theme_options["headerlight"] = obt_translate("Header and footer")." ## radio|light|<span style=\"background:#eef2f6;border:1px solid #c8c8c8;line-height:170%;padding:1px 10px;\">".obt_translate("Light")."</span>|dark|<span style=\"background:#134c8d;border:1px solid #134c8d;color:#ffffff;line-height: 170%;padding: 1px 10px;\">".obt_translate("Dark")."</span>";
	$theme_options["background"] = obt_translate("Background")." ## radio|white|<span style=\"background:#ffffff;border:1px solid #c8c8c8;line-height:170%;padding:1px 10px;\">".obt_translate("White")."</span>|lightgray|<span style=\"background:#fafafa;border:1px solid #c8c8c8;line-height:170%;padding:1px 10px;\">".obt_translate("Light gray")."</span>";

	$theme_options["general-separator"] = obt_translate("General options")." ## separator";
	$theme_options["align"] = obt_translate("Body alignment")." ## radio|center|".obt_translate("Center")."|left|".obt_translate("Left");
	$theme_options["width"] = obt_translate("Body width")." ## ## ".obt_translate("Fixed measure (i.e. 780px) or percentage (i.e. 90%)");
	$theme_options["sidebaralign"] = obt_translate("Sidebar alignment")." ## radio|left|<span style=\"background:#ffffff;border:1px solid #c8c8c8;border-left:15px solid #646464;color:#000000;line-height:170%;padding:1px 10px;\">".obt_translate("Left")."</span>|right|<span style=\"background:#ffffff;border:1px solid #c8c8c8;border-right: 15px solid #646464;color:#000000;line-height: 170%;padding: 1px 10px;\">".obt_translate("Right")."</span>";
	$theme_options["sidebarwidth"] = obt_translate("Sidebar width")." ## ## ".obt_translate("Fixed measure (i.e. 300px) or percentage (i.e. 40%)");
	$theme_options["leftsidebarwidth"] = obt_translate("Sidebar left column width")." ## ## ".obt_translate("Fixed measure (i.e. 140px) or percentage (i.e. 50%)");
	$theme_options["menu"] = obt_translate("Pages menu")." ## radio|horizontal|".obt_translate("Horizontal menu on the header")."|regular|".obt_translate("Regular menu on the sidebar");
	$theme_options["image"] = obt_translate("Header image")." ## ## ".obt_translate("Specify the full url of the image you want to be displayed in the header");
	$theme_options["imagenomargins"] = "&nbsp; ## checkbox";
	$theme_options["imagenomargins"] .= "|imagenomargins|1|".obt_translate("Display image without margins");
	$theme_options["imagewidth"] = obt_translate("Image width")." ## ## ".obt_translate("Specify the width for the previous image, just a number (i.e. 200)");
	$theme_options["imageheight"] = obt_translate("Image height")." ## ## ".obt_translate("Specify the height for the previous image, just a number (i.e. 50)");
	
	$theme_options["posts-separator"] = obt_translate("Posts")." ## separator";
	$theme_options["posts"] = obt_translate("Homepage")." ## radio|full|".obt_translate("Full text")."|excerpt|".obt_translate("First X words (or excerpt if available)")."|paragraphs|".obt_translate("First X paragraphs");
	$theme_options["posts-words"] = "&nbsp; ## ## ".obt_translate("Number of words");
	$theme_options["posts-paragraphs"] = "&nbsp; ## ## ".obt_translate("Number of paragraphs");
	$theme_options["posts-archives"] = obt_translate("Archives (categories, dates, tags...)")." ## radio|full|".obt_translate("Full text")."|excerpt|".obt_translate("First X words (or excerpt if available)")."|paragraphs|".obt_translate("First X paragraphs");
	$theme_options["posts-archives-words"] = "&nbsp; ## ## ".obt_translate("Number of words");
	$theme_options["posts-archives-paragraphs"] = "&nbsp; ## ## ".obt_translate("Number of paragraphs");
	
	$theme_options["comments-separator"] = obt_translate("Comments")." ## separator";
	$theme_options["comments-order"] = obt_translate("Order")." ## radio|newer|".obt_translate("Newer first")."|older|".obt_translate("Older first");
	$theme_options["comments-pagination"] = obt_translate("Comments per page")." ## ## ".obt_translate("Enter 0 to avoid comment pagination");
	$theme_options["comments-post-full"] = obt_translate("Post page always full")." ## checkbox";
	$theme_options["comments-post-full"] .= "|comments-post-full|1|".obt_translate("If order is set to \"newer first\", this will make post pages contain the maximum number of comments allowed, but comment permalinks could vary over time");
	
	$theme_options["social-separator"] = obt_translate("Social buttons")." ## separator";
	$theme_options["subscribe"] = obt_translate("Feed aggregators")." ## checkbox";
	$theme_options["subscribe"] .= "|subscribe-bloglines|1|Bloglines";
	$theme_options["subscribe"] .= "|subscribe-feedster|1|Feedster";
	$theme_options["subscribe"] .= "|subscribe-google|1|Google Reader";
	$theme_options["subscribe"] .= "|subscribe-live|1|Live";
	$theme_options["subscribe"] .= "|subscribe-aol|1|MyAOL";
	$theme_options["subscribe"] .= "|subscribe-yahoo|1|MyYahoo";
	$theme_options["subscribe"] .= "|subscribe-netvibes|1|Netvibes";
	$theme_options["subscribe"] .= "|subscribe-newsgator|1|Newsgator";
	$theme_options["subscribe"] .= "|subscribe-rojo|1|Rojo";
	$theme_options["share"] = obt_translate("Social bookmarkers")." ## checkbox";
	$theme_options["share"] .= "|share-barrapunto|1|Barrapunto";
	$theme_options["share"] .= "|share-blinklist|1|BlinkList";
	$theme_options["share"] .= "|share-blogmemes|1|BlogMemes";
	$theme_options["share"] .= "|share-corank|1|CoRank";
	$theme_options["share"] .= "|share-corank-es|1|CoRank Espa&ntilde;ol";
	$theme_options["share"] .= "|share-delicious|1|Delicious";
	$theme_options["share"] .= "|share-digg|1|Digg";
	$theme_options["share"] .= "|share-enchilame|1|Ench&iacute;lame";
	$theme_options["share"] .= "|share-fark|1|Fark";
	$theme_options["share"] .= "|share-fresqui-act|1|Fresqui Actualidad";
	$theme_options["share"] .= "|share-fresqui-ocio|1|Fresqui Ocio";
	$theme_options["share"] .= "|share-fresqui-tec|1|Fresqui Tecnolog&iacute;a";
	$theme_options["share"] .= "|share-furl|1|Furl";
	$theme_options["share"] .= "|share-google|1|Google Bookmarks";
	$theme_options["share"] .= "|share-live|1|Live Favorites";
	$theme_options["share"] .= "|share-magnolia|1|Magnolia";
	$theme_options["share"] .= "|share-meneame|1|Men&eacute;ame";
	$theme_options["share"] .= "|share-neodiario|1|Neodiario";
	$theme_options["share"] .= "|share-netscape|1|Netscape";
	$theme_options["share"] .= "|share-newsvine|1|Newsvine";
	$theme_options["share"] .= "|share-reddit|1|Reddit";
	$theme_options["share"] .= "|share-rojo|1|Rojo";
	$theme_options["share"] .= "|share-slashdot|1|Slashdot";
	$theme_options["share"] .= "|share-spurl|1|Spurl";
	$theme_options["share"] .= "|share-stumbleupon|1|Stumbleupon";
	$theme_options["share"] .= "|share-technorati|1|Technorati Favorites";
	$theme_options["share"] .= "|share-yahoo|1|Yahoo MyWeb";
	
	$theme_options["feed-separator"] = obt_translate("Feed options")." ## separator";
	$theme_options["feed"] = obt_translate("Enable this feeds")." ## checkbox";
	$theme_options["feed"] .= "|feed|1|".obt_translate("Posts")." (".obt_translate("you shouldn't disable this").")";
	$theme_options["feed"] .= "|feed-comments|1|".obt_translate("Comments");
	$theme_options["feed"] .= "|feed-single|1|".obt_translate("Comments for each post");
	$theme_options["feed"] .= "|feed-categories|1|".obt_translate("Categories");
	$theme_options["feed"] .= "|feed-tags|1|".obt_translate("Tags");;
	$theme_options["feed"] .= "|feed-bloggers|1|".obt_translate("Bloggers");
	$theme_options["alternate-feed"] = obt_translate("Alternate feed (posts)")." ## ## ".obt_translate("Specify the full url for the alternate feed (Feedburner, etc) for posts");
	$theme_options["alternate-feed-comments"] = obt_translate("Alternate feed (comments)")." ## ## ".obt_translate("Specify the full url for the alternate feed (Feedburner, etc) for comments");
	$theme_options["feed-type"] = obt_translate("Enable this feed types")." ## checkbox";
	$theme_options["feed-type"] .= "|feed-rss2|1|RSS 2.0 (".obt_translate("you shouldn't disable this").")";
	$theme_options["feed-type"] .= "|feed-rss|1|RSS";
	$theme_options["feed-type"] .= "|feed-atom|1|Atom";
	$theme_options["feed-type"] .= "|feed-rdf|1|RDF";
	$theme_options["feed-content"] = obt_translate("Feed content")." ## checkbox";
	$theme_options["feed-content"] .= "|feed-content-related-posts|1|".obt_translate("Add related posts to the feed content");
	$theme_options["feed-content"] .= "|feed-content-categories|1|".obt_translate("Add categories to the feed content");
	$theme_options["feed-content"] .= "|feed-content-tags|1|".obt_translate("Add tags to the feed content");
	$theme_options["feed-content"] .= "|feed-content-share|1|".obt_translate("Add social bookmarkers to the feed content");
	$theme_options["feed-content"] .= "|feed-content-attribution|1|".obt_translate("Add attribution links to the feed content");
	
	$theme_options["subscribe-email-separator"] = obt_translate("Email subscription form")." ## separator";
	$theme_options["subscribe-email-form"] = obt_translate("Email subscription form")." ## radio|none|".obt_translate("None")."|feedburner|FeedBurner|feedblitz|FeedBlitz";
	$theme_options["subscribe-email-feedburner"] = obt_translate("FeedBurner ID")." ## ## ".obt_translate("Enable this option in FeedBurner and look for XXX in the code").": http://feeds.feedburner.com/~e?ffid=<strong>XXX</strong>";
	$theme_options["subscribe-email-feedblitz"] = obt_translate("FeedBlitz ID")." ## ## ".obt_translate("Look for XXX in the FeedBlitz code").": &lt;input name=\"FEEDID\" type=\"hidden\" value=\"<strong>XXX</strong>\"&gt;";
	
	$theme_options["other-separator"] = obt_translate("Other options")." ## separator";
	$theme_options["comment-notification"] = obt_translate("Comment email notification")." ## checkbox";
	$theme_options["comment-notification"] .= "|comment-notification|1|".obt_translate("Enable comment email notification");
	$theme_options["comment-notification"] .= "|comment-notification-default|1|".obt_translate("Check notification checkbox by default");
	$theme_options["site-title"] = obt_translate("Site name in titles")." ## radio|beginning|".obt_translate("Display site name at the beginning of the titles")."|end|".obt_translate("Display site name at the end of the titles");
	$theme_options["meta-noindex"] = obt_translate("Noindex meta tag in archives")." ## radio|none|".obt_translate("No meta tag")."|archives|".obt_translate("Add noindex meta tag to archives (categories, search, tags...) to avoid content duplication in search engines")."|paginated-archives|".obt_translate("Add noindex meta tag to archives except for the first page");
	$theme_options["gravatars"] = "Gravatars ## checkbox";
	$theme_options["gravatars"] .= "|gravatars|1|".obt_translate("Include %1 in comments","<a href=\"http://www.gravatar.com/\">Gravatars</a> (Globally Recognized Avatars)");
	$theme_options["thumbnail-width"] = obt_translate("Thumbnails width")." ## ## ".obt_translate("Max width for thumbnails when uploading images");
	
	themetoolkit("obt_theme",$theme_options,__FILE__);
};

IF ($obt_theme){
	IF (!$obt_theme->is_installed()){
		$theme_default_options["linkhue"] = "150";
		$theme_default_options["linksaturation"] = "200";
		$theme_default_options["headerhue"] = "150";
		$theme_default_options["headersaturation"] = "70";
		$theme_default_options["headerlight"] = "light";
		$theme_default_options["background"] = "white";
		$theme_default_options["align"] = "center";
		$theme_default_options["width"] = "90%";
		$theme_default_options["sidebaralign"] = "left";
		$theme_default_options["sidebarwidth"] = "40%";
		$theme_default_options["leftsidebarwidth"] = "50%";
		$theme_default_options["menu"] = "horizontal";
		$theme_default_options["image"] = "http://";
		$theme_default_options["imagewidth"] = "200";
		$theme_default_options["imageheight"] = "50";
		$theme_default_options["posts"] = "full";
		$theme_default_options["posts-words"] = "55";
		$theme_default_options["posts-paragraphs"] = "1";
		$theme_default_options["posts-archives"] = "paragraphs";
		$theme_default_options["posts-archives-words"] = "55";
		$theme_default_options["posts-archives-paragraphs"] = "1";
		$theme_default_options["comments-order"] = "older";
		$theme_default_options["comments-pagination"] = "0";
		$theme_default_options["subscribe-bloglines"] = "1";
		$theme_default_options["subscribe-google"] = "1";
		$theme_default_options["subscribe-live"] = "1";
		$theme_default_options["subscribe-yahoo"] = "1";
		$theme_default_options["subscribe-netvibes"] = "1";
		$theme_default_options["subscribe-newsgator"] = "1";
		$theme_default_options["subscribe-rojo"] = "1";
		$theme_default_options["share-barrapunto"] = "1";
		$theme_default_options["share-corank-es"] = "1";
		$theme_default_options["share-delicious"] = "1";
		$theme_default_options["share-enchilame"] = "1";
		$theme_default_options["share-fresqui-ocio"] = "1";
		$theme_default_options["share-meneame"] = "1";
		$theme_default_options["share-technorati"] = "1";
		$theme_default_options["feed"] = "1";
		$theme_default_options["feed-comments"] = "1";
		$theme_default_options["feed-single"] = "1";
		$theme_default_options["feed-categories"] = "1";
		$theme_default_options["feed-tags"] = "1";
		$theme_default_options["feed-bloggers"] = "1";
		$theme_default_options["alternate-feed"] = "http://";
		$theme_default_options["alternate-feed-comments"] = "http://";
		$theme_default_options["feed-rss2"] = "1";
		$theme_default_options["feed-rss"] = "1";
		$theme_default_options["feed-atom"] = "1";
		$theme_default_options["feed-rdf"] = "1";
		$theme_default_options["subscribe-email-form"] = "none";
		$theme_default_options["comment-notification"] = "1";
		$theme_default_options["site-title"] = "end";
		$theme_default_options["meta-noindex"] = "none";
		$theme_default_options["thumbnail-width"] = "250";
		$result = $obt_theme->store_options($theme_default_options);
	};
};

FUNCTION obt_get_themeoption($name){
	global $obt_theme;
	RETURN trim($obt_theme->option[$name]);
};
FUNCTION obt_themeoption($name){
	echo obt_get_themeoption($name);
};
?>
